# WTV Driver Market V2.2 TEST

Nur für den separaten Testbot.

## Neu

### `/adddriver` ohne Formular
Alle Werte werden direkt im Slash-Command eingetragen. Dadurch kannst du während
der Eingabe problemlos in andere Discord-Channels wechseln und Daten nachsehen.

Beispiel:

```text
/adddriver fahrer:Mario marktwert:25 vertrag:3 ausstiegsklausel:50 gehalt:8 boni:1 Mio. pro Sieg
```

Optional:
- Fahrer-Ausstiegsklausel
- Team-Kündigungsklausel

### Automatische Formatierung

Marktwert:
- `25` → `25 Mio. €`
- `12,5` → `12,5 Mio. €`

Gehalt:
- `8` → `8 Mio. €/Saison`

Normale Ablöse-/Ausstiegsklausel:
- `50` → `50 Mio. €`
- `35,5` → `35,5 Mio. €`
- `-` oder `keine` → keine Klausel

Vertrag:
- `3` → `3 Saisons`
- `1` → `1 Saison`
- `0` → `Kein Vertrag`

Freitext bleiben:
- Boni
- Fahrer-Ausstiegsklausel
- Team-Kündigungsklausel

### Weiterhin enthalten
- `/editdriver` ohne Popup
- `/transferdriver` ohne Popup
- `/driverinfo` mit Vertrag → Gehalt → Boni → Klauseln
- Railway-Volume-Speicherung
- automatisches `driver_market.backup.json`
- `/datastatus`
- `/auditlog`
- `/version`
- `/seasonstatus`
- WTV Rot/Grün/Weiß im Testbot
