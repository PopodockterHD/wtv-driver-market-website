# WTV Driver Market V3.4

## Neu in V3.4
- Neuer Command `/saison`
- Nur Discord-Administrator / Server-Owner
- Setzt die aktuelle Saisonnummer direkt, z. B. auf Saison 6
- Verändert dabei **keine Vertragslaufzeiten**
- `/help` wurde um `/saison` ergänzt

## Warum `/saison`?
Wenn die Liga z. B. bereits in Saison 6 ist, muss nicht fünfmal `/newseason`
ausgeführt werden. Stattdessen:

```text
/saison nummer:6
```

Danach zeigt der Bot direkt Saison 6 an.

## Öffentlich
- `/drivermarket`
- `/alldrivers`
- `/driverinfo`
- `/topmarketvalue`
- `/driverhistory`
- `/transfers`
- `/help`

## Nur Transferleitung
Rollen-ID: `1543299106687164466`

- `/adddriver`
- `/editdriver`
- `/transferdriver`
- `/removedriver`
- `/renewcontract`
- `/setmarketvalue`
- `/botstatus`

## Nur Discord-Administrator / Owner
- `/saison`
- `/newseason`
- `/undoseason`

## Hinweis
`/saison` setzt nur die Saisonnummer.
`/newseason` ist weiterhin der Command, der die Saison erhöht und dabei
unterstützte Vertragslaufzeiten reduziert.
