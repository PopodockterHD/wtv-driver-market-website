import asyncio
import copy
import json
import os
import re
import time
from pathlib import Path

import discord
from discord import app_commands
from discord.ext import commands
from dotenv import load_dotenv


# =========================================================
# KONFIGURATION
# =========================================================

load_dotenv()

TOKEN = os.getenv("DISCORD_TOKEN")
GUILD_ID = os.getenv("GUILD_ID")

# Rolle für Transfer-/Vertragsverwaltung.
# Auf Railway als Variable TRANSFER_ADMIN_ROLE_ID eintragen.
# Solange keine ID eingetragen ist, können diese Commands nur echte
# Discord-Administratoren / der Server-Owner benutzen.
TRANSFER_ADMIN_ROLE_ID = 1543299106687164466

# Lokal: Datei neben bot.py
# Railway: automatisch das verbundene Volume verwenden.
VOLUME_PATH = os.getenv("RAILWAY_VOLUME_MOUNT_PATH")
DATA_DIR = Path(VOLUME_PATH) if VOLUME_PATH else Path(".")
DATA_DIR.mkdir(parents=True, exist_ok=True)
DATA_FILE = DATA_DIR / "driver_market.json"

data_lock = asyncio.Lock()


# =========================================================
# DESIGN
# =========================================================

BRAND_COLOR = 0x7C5CFC
PUBLIC_COLOR = 0x5865F2
SUCCESS_COLOR = 0x57F287
WARNING_COLOR = 0xFEE75C
DANGER_COLOR = 0xED4245
GOLD_COLOR = 0xF1C40F

TEAM_COLORS = {
    "Red Bull Racing": 0x1E41FF,
    "Ferrari": 0xE8002D,
    "Frei": 0x95A5A6,
}


# =========================================================
# TEAM-ROLLEN
# =========================================================

TEAM_ROLES = {
    "Red Bull Racing": 1542621152831209563,
    "Ferrari": 1542621040058826842,
}

TRANSFER_TEAM_CHOICES = [
    app_commands.Choice(name=team_name, value=team_name)
    for team_name in TEAM_ROLES
]
TRANSFER_TEAM_CHOICES.append(
    app_commands.Choice(name="Frei / Free Agent", value="Frei")
)


def get_team_role_mention(team_name: str) -> str | None:
    role_id = TEAM_ROLES.get(team_name)
    return f"<@&{role_id}>" if role_id else None


def get_team_from_member(member: discord.Member) -> str:
    member_role_ids = {role.id for role in member.roles}

    for team_name, role_id in TEAM_ROLES.items():
        if role_id in member_role_ids:
            return team_name

    return "Frei"


async def change_member_team_role(
    member: discord.Member,
    new_team: str,
) -> tuple[bool, str]:
    known_role_ids = set(TEAM_ROLES.values())
    roles_to_remove = [
        role for role in member.roles
        if role.id in known_role_ids
    ]

    try:
        if roles_to_remove:
            await member.remove_roles(
                *roles_to_remove,
                reason="WTV Driver Market Transfer",
            )

        if new_team != "Frei":
            role_id = TEAM_ROLES.get(new_team)
            role = member.guild.get_role(role_id) if role_id else None

            if role is None:
                return False, (
                    f"Die Discord-Rolle für **{new_team}** wurde nicht gefunden."
                )

            await member.add_roles(
                role,
                reason="WTV Driver Market Transfer",
            )

    except discord.Forbidden:
        return False, (
            "Ich darf die Teamrolle nicht ändern. "
            "Der Bot braucht **Rollen verwalten** und seine Bot-Rolle "
            "muss über den Teamrollen stehen."
        )
    except discord.HTTPException as exc:
        return False, f"Discord konnte die Rollen nicht ändern: {exc}"

    return True, ""


# =========================================================
# DATENSPEICHER
# =========================================================

def default_data() -> dict:
    return {
        "guilds": {},
        "transfers": {},
        "seasons": {},
        "season_backups": {},
    }


def load_data() -> dict:
    if not DATA_FILE.exists():
        return default_data()

    try:
        with DATA_FILE.open("r", encoding="utf-8") as f:
            data = json.load(f)
    except (json.JSONDecodeError, OSError):
        return default_data()

    # Rückwärtskompatibel ältere Dateien ergänzen
    data.setdefault("guilds", {})
    data.setdefault("transfers", {})
    data.setdefault("seasons", {})
    data.setdefault("season_backups", {})
    return data


def save_data(data: dict) -> None:
    temp_file = DATA_FILE.with_suffix(".tmp")
    with temp_file.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    temp_file.replace(DATA_FILE)


def get_guild_drivers(data: dict, guild_id: int) -> list[dict]:
    return data.setdefault("guilds", {}).setdefault(str(guild_id), [])


def get_guild_transfers(data: dict, guild_id: int) -> list[dict]:
    return data.setdefault("transfers", {}).setdefault(str(guild_id), [])


def get_guild_season(data: dict, guild_id: int) -> int:
    seasons = data.setdefault("seasons", {})
    return int(seasons.setdefault(str(guild_id), 1))


def set_guild_season(data: dict, guild_id: int, season: int) -> None:
    data.setdefault("seasons", {})[str(guild_id)] = max(1, int(season))


def get_season_backup(data: dict, guild_id: int) -> dict | None:
    return data.setdefault("season_backups", {}).get(str(guild_id))


def set_season_backup(data: dict, guild_id: int, backup: dict) -> None:
    data.setdefault("season_backups", {})[str(guild_id)] = backup


def clear_season_backup(data: dict, guild_id: int) -> None:
    data.setdefault("season_backups", {}).pop(str(guild_id), None)


def find_driver(drivers: list[dict], user_id: int) -> dict | None:
    return next((d for d in drivers if d.get("user_id") == user_id), None)


def ensure_driver_history(driver: dict) -> list[dict]:
    return driver.setdefault("history", [])


def add_driver_history(driver: dict, text: str) -> None:
    history = ensure_driver_history(driver)
    history.append({
        "timestamp": int(time.time()),
        "text": text,
    })

    # Datei klein halten
    if len(history) > 100:
        del history[:-100]


def add_transfer_history(
    data: dict,
    guild_id: int,
    driver: dict,
    old_team: str,
    new_team: str,
) -> None:
    transfers = get_guild_transfers(data, guild_id)
    transfers.append({
        "timestamp": int(time.time()),
        "season": get_guild_season(data, guild_id),
        "user_id": driver["user_id"],
        "name": driver["name"],
        "from": old_team,
        "to": new_team,
    })

    if len(transfers) > 200:
        del transfers[:-200]


# =========================================================
# HILFSFUNKTIONEN
# =========================================================

def team_display(team_name: str) -> str:
    return get_team_role_mention(team_name) or (
        "🆓 Freier Fahrer" if team_name == "Frei" else team_name
    )


def contract_after_new_season(contract: str) -> tuple[str, bool]:
    """
    Unterstützt z.B.:
    3
    3 Saisons
    1 Saison

    Freitext wie 'bis Ende 2027' bleibt unverändert.
    """
    text = contract.strip()

    match = re.fullmatch(
        r"(\d+)\s*(?:saison|saisons|season|seasons)?",
        text,
        flags=re.IGNORECASE,
    )

    if not match:
        return contract, False

    seasons = int(match.group(1))
    new_value = max(0, seasons - 1)

    if new_value == 1:
        return "1 Saison", True
    return f"{new_value} Saisons", True


def parse_market_value(value: str) -> float:
    text = value.lower().strip()

    match = re.search(r"[-+]?\d[\d.,]*", text)
    if not match:
        return float("-inf")

    number = match.group(0)

    # Deutsche Schreibweise 25,5
    if "," in number and "." not in number:
        number = number.replace(",", ".")
    elif "." in number and "," in number:
        # 1.250,5 -> 1250.5
        if number.rfind(",") > number.rfind("."):
            number = number.replace(".", "").replace(",", ".")
        else:
            number = number.replace(",", "")
    elif number.count(".") > 1:
        number = number.replace(".", "")

    try:
        numeric = float(number)
    except ValueError:
        return float("-inf")

    if "mrd" in text or "billion" in text:
        return numeric * 1_000_000_000
    if "mio" in text or "million" in text:
        return numeric * 1_000_000
    if "tsd" in text or re.search(r"\bk\b", text):
        return numeric * 1_000

    # In eurer Liga werden häufig einfach Werte wie "12" eingetragen.
    # Kleine nackte Zahlen werden deshalb als Millionen interpretiert.
    if abs(numeric) < 100_000:
        return numeric * 1_000_000

    return numeric


def format_driver_line(driver: dict) -> str:
    return (
        f"🏎️ **{driver['name']}**\n"
        f"└ {team_display(driver['team'])}  •  "
        f"📄 {driver['contract']}  •  💰 {driver['market_value']}"
    )


def footer_text(data: dict, guild_id: int) -> str:
    return f"WTV Driver Market • Saison {get_guild_season(data, guild_id)}"


# =========================================================
# BERECHTIGUNGEN
# =========================================================

class TransferPermissionError(app_commands.CheckFailure):
    pass


class AdministratorPermissionError(app_commands.CheckFailure):
    pass


def is_real_admin(interaction: discord.Interaction) -> bool:
    if interaction.guild is None or not isinstance(interaction.user, discord.Member):
        return False

    if interaction.guild.owner_id == interaction.user.id:
        return True

    return interaction.user.guild_permissions.administrator


def transfer_staff_only():
    async def predicate(interaction: discord.Interaction) -> bool:
        if interaction.guild is None or not isinstance(interaction.user, discord.Member):
            raise TransferPermissionError()

        # Ausschließlich die Transferleitungs-Rolle zählt.
        # Administrator oder Server-Owner allein reicht nicht.
        if any(role.id == TRANSFER_ADMIN_ROLE_ID for role in interaction.user.roles):
            return True

        raise TransferPermissionError()

    return app_commands.check(predicate)


def administrator_only():
    async def predicate(interaction: discord.Interaction) -> bool:
        if is_real_admin(interaction):
            return True
        raise AdministratorPermissionError()

    return app_commands.check(predicate)


# =========================================================
# BOT
# =========================================================

class TransferBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.members = True
        super().__init__(command_prefix="!", intents=intents)

    async def setup_hook(self) -> None:
        if GUILD_ID:
            guild = discord.Object(id=int(GUILD_ID))
            self.tree.copy_global_to(guild=guild)
            synced = await self.tree.sync(guild=guild)
            print(
                f"{len(synced)} Slash-Commands mit Server "
                f"{GUILD_ID} synchronisiert."
            )
        else:
            synced = await self.tree.sync()
            print(f"{len(synced)} globale Slash-Commands synchronisiert.")


bot = TransferBot()


# =========================================================
# VIEWS
# =========================================================

class MarketView(discord.ui.View):
    def __init__(
        self,
        teams: list[tuple[str, list[dict]]],
        author_id: int,
        guild_id: int,
    ):
        super().__init__(timeout=300)
        self.teams = teams
        self.author_id = author_id
        self.guild_id = guild_id
        self.index = 0
        self.message: discord.Message | None = None
        self.update_buttons()

    def update_buttons(self) -> None:
        self.previous.disabled = self.index <= 0
        self.next.disabled = self.index >= len(self.teams) - 1

    def make_embed(self) -> discord.Embed:
        data = load_data()
        team_name, drivers = self.teams[self.index]
        color = TEAM_COLORS.get(team_name, BRAND_COLOR)

        embed = discord.Embed(
            title=f"🏁 WTV DRIVER MARKET • {team_name.upper()}",
            description=(
                f"**Team:** {team_display(team_name)}\n"
                f"**Fahrer:** {len(drivers)}"
            ),
            color=color,
        )

        for number, driver in enumerate(drivers, start=1):
            embed.add_field(
                name=f"👤 {number}. {driver['name']}",
                value=(
                    f"💰 **Marktwert:** {driver['market_value']}\n"
                    f"📄 **Vertrag:** {driver['contract']}\n"
                    f"🔓 **Ausstiegsklausel:** {driver['release_clause']}\n"
                    f"💵 **Gehalt:** {driver['salary']}\n"
                    f"🎯 **Boni:** {driver['bonuses']}\n"
                    f"🔗 <@{driver['user_id']}>"
                ),
                inline=False,
            )

        embed.set_footer(
            text=(
                f"{footer_text(data, self.guild_id)} • "
                f"Team {self.index + 1}/{len(self.teams)}"
            )
        )
        return embed

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.author_id:
            await interaction.response.send_message(
                "Öffne bitte deinen eigenen Fahrermarkt mit `/drivermarket`.",
                ephemeral=True,
            )
            return False
        return True

    @discord.ui.button(label="◀ Zurück", style=discord.ButtonStyle.secondary)
    async def previous(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button,
    ) -> None:
        self.index -= 1
        self.update_buttons()
        await interaction.response.edit_message(
            embed=self.make_embed(),
            view=self,
        )

    @discord.ui.button(label="Weiter ▶", style=discord.ButtonStyle.secondary)
    async def next(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button,
    ) -> None:
        self.index += 1
        self.update_buttons()
        await interaction.response.edit_message(
            embed=self.make_embed(),
            view=self,
        )


class AllDriversView(discord.ui.View):
    def __init__(
        self,
        drivers: list[dict],
        author_id: int,
        guild_id: int,
        per_page: int = 12,
    ):
        super().__init__(timeout=300)
        self.drivers = drivers
        self.author_id = author_id
        self.guild_id = guild_id
        self.per_page = per_page
        self.index = 0
        self.message: discord.Message | None = None
        self.page_count = max(1, (len(drivers) + per_page - 1) // per_page)
        self.update_buttons()

    def update_buttons(self) -> None:
        self.previous.disabled = self.index <= 0
        self.next.disabled = self.index >= self.page_count - 1

    def make_embed(self) -> discord.Embed:
        data = load_data()
        start = self.index * self.per_page
        end = start + self.per_page
        page_drivers = self.drivers[start:end]

        embed = discord.Embed(
            title="👥 WTV • ALLE FAHRER",
            description="\n\n".join(
                format_driver_line(driver) for driver in page_drivers
            ),
            color=PUBLIC_COLOR,
        )
        embed.set_footer(
            text=(
                f"{footer_text(data, self.guild_id)} • "
                f"Seite {self.index + 1}/{self.page_count}"
            )
        )
        return embed

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.author_id:
            await interaction.response.send_message(
                "Öffne bitte deine eigene Liste mit `/alldrivers`.",
                ephemeral=True,
            )
            return False
        return True

    @discord.ui.button(label="◀ Zurück", style=discord.ButtonStyle.secondary)
    async def previous(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button,
    ) -> None:
        self.index -= 1
        self.update_buttons()
        await interaction.response.edit_message(
            embed=self.make_embed(),
            view=self,
        )

    @discord.ui.button(label="Weiter ▶", style=discord.ButtonStyle.secondary)
    async def next(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button,
    ) -> None:
        self.index += 1
        self.update_buttons()
        await interaction.response.edit_message(
            embed=self.make_embed(),
            view=self,
        )


class NewSeasonConfirmView(discord.ui.View):
    def __init__(self, author_id: int, guild_id: int):
        super().__init__(timeout=60)
        self.author_id = author_id
        self.guild_id = guild_id

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.author_id:
            await interaction.response.send_message(
                "Nur die Person, die `/newseason` gestartet hat, kann bestätigen.",
                ephemeral=True,
            )
            return False
        return True

    @discord.ui.button(
        label="Neue Saison starten",
        emoji="✅",
        style=discord.ButtonStyle.danger,
    )
    async def confirm(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button,
    ) -> None:
        async with data_lock:
            data = load_data()
            drivers = get_guild_drivers(data, self.guild_id)
            current_season = get_guild_season(data, self.guild_id)

            # Nur die Verträge sichern, die /newseason verändert.
            backup = {
                "previous_season": current_season,
                "timestamp": int(time.time()),
                "contracts": {
                    str(driver["user_id"]): driver["contract"]
                    for driver in drivers
                },
            }
            set_season_backup(data, self.guild_id, backup)

            changed = 0
            skipped = 0

            for driver in drivers:
                new_contract, supported = contract_after_new_season(
                    driver["contract"]
                )

                if supported:
                    if new_contract != driver["contract"]:
                        old_contract = driver["contract"]
                        driver["contract"] = new_contract
                        add_driver_history(
                            driver,
                            (
                                f"📅 Saisonwechsel: Vertrag "
                                f"{old_contract} → {new_contract}"
                            ),
                        )
                        changed += 1
                else:
                    skipped += 1

            set_guild_season(data, self.guild_id, current_season + 1)
            save_data(data)

        for child in self.children:
            child.disabled = True

        embed = discord.Embed(
            title="🏁 Neue Saison gestartet",
            description=(
                f"**Saison {current_season + 1}** ist jetzt aktiv.\n\n"
                f"📄 Verträge angepasst: **{changed}**\n"
                f"ℹ️ Freitext-Verträge übersprungen: **{skipped}**\n\n"
                "Mit `/undoseason` kann der letzte Saisonwechsel "
                "wieder rückgängig gemacht werden."
            ),
            color=SUCCESS_COLOR,
        )

        await interaction.response.edit_message(embed=embed, view=self)

    @discord.ui.button(
        label="Abbrechen",
        emoji="❌",
        style=discord.ButtonStyle.secondary,
    )
    async def cancel(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button,
    ) -> None:
        for child in self.children:
            child.disabled = True

        embed = discord.Embed(
            title="❌ Saisonwechsel abgebrochen",
            description="Es wurde nichts verändert.",
            color=DANGER_COLOR,
        )
        await interaction.response.edit_message(embed=embed, view=self)


class UndoSeasonConfirmView(discord.ui.View):
    def __init__(self, author_id: int, guild_id: int):
        super().__init__(timeout=60)
        self.author_id = author_id
        self.guild_id = guild_id

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.author_id:
            await interaction.response.send_message(
                "Nur die Person, die `/undoseason` gestartet hat, kann bestätigen.",
                ephemeral=True,
            )
            return False
        return True

    @discord.ui.button(
        label="Saisonwechsel rückgängig",
        emoji="↩️",
        style=discord.ButtonStyle.danger,
    )
    async def confirm(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button,
    ) -> None:
        async with data_lock:
            data = load_data()
            backup = get_season_backup(data, self.guild_id)

            if not backup:
                await interaction.response.send_message(
                    "❌ Es gibt keinen Saisonwechsel zum Wiederherstellen.",
                    ephemeral=True,
                )
                return

            drivers = get_guild_drivers(data, self.guild_id)
            contracts = backup.get("contracts", {})
            restored = 0

            for driver in drivers:
                old_contract = contracts.get(str(driver["user_id"]))
                if old_contract is not None:
                    driver["contract"] = old_contract
                    add_driver_history(
                        driver,
                        f"↩️ Saisonwechsel rückgängig: Vertrag wieder {old_contract}",
                    )
                    restored += 1

            previous_season = int(backup.get("previous_season", 1))
            set_guild_season(data, self.guild_id, previous_season)
            clear_season_backup(data, self.guild_id)
            save_data(data)

        for child in self.children:
            child.disabled = True

        embed = discord.Embed(
            title="↩️ Saisonwechsel rückgängig gemacht",
            description=(
                f"Zurück auf **Saison {previous_season}**.\n"
                f"📄 Verträge wiederhergestellt: **{restored}**"
            ),
            color=SUCCESS_COLOR,
        )
        await interaction.response.edit_message(embed=embed, view=self)

    @discord.ui.button(
        label="Abbrechen",
        emoji="❌",
        style=discord.ButtonStyle.secondary,
    )
    async def cancel(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button,
    ) -> None:
        for child in self.children:
            child.disabled = True

        embed = discord.Embed(
            title="❌ Wiederherstellung abgebrochen",
            description="Es wurde nichts verändert.",
            color=DANGER_COLOR,
        )
        await interaction.response.edit_message(embed=embed, view=self)


# =========================================================
# ÖFFENTLICHE COMMANDS
# =========================================================

@bot.tree.command(
    name="drivermarket",
    description="Zeigt den aktuellen Fahrermarkt nach Teams an.",
)
@app_commands.guild_only()
async def drivermarket(interaction: discord.Interaction) -> None:
    data = load_data()
    drivers = get_guild_drivers(data, interaction.guild_id)

    if not drivers:
        await interaction.response.send_message(
            "Der Fahrermarkt ist noch leer."
        )
        return

    grouped: dict[str, list[dict]] = {}
    for driver in drivers:
        grouped.setdefault(driver["team"], []).append(driver)

    def team_sort(item: tuple[str, list[dict]]) -> tuple[int, str]:
        team_name = item[0].strip().lower()
        return (1 if team_name == "frei" else 0, team_name)

    teams = sorted(grouped.items(), key=team_sort)
    view = MarketView(teams, interaction.user.id, interaction.guild_id)

    await interaction.response.send_message(
        embed=view.make_embed(),
        view=view,
    )
    view.message = await interaction.original_response()


@bot.tree.command(
    name="alldrivers",
    description="Zeigt alle Fahrer kompakt in einer Liste an.",
)
@app_commands.guild_only()
async def alldrivers(interaction: discord.Interaction) -> None:
    data = load_data()
    drivers = get_guild_drivers(data, interaction.guild_id)

    if not drivers:
        await interaction.response.send_message("Die Fahrerliste ist noch leer.")
        return

    sorted_drivers = sorted(
        drivers,
        key=lambda d: (
            1 if d["team"].strip().lower() == "frei" else 0,
            d["team"].lower(),
            d["name"].lower(),
        ),
    )

    view = AllDriversView(
        sorted_drivers,
        interaction.user.id,
        interaction.guild_id,
    )
    await interaction.response.send_message(
        embed=view.make_embed(),
        view=view,
    )
    view.message = await interaction.original_response()


@bot.tree.command(
    name="driverinfo",
    description="Zeigt alle Vertragsinformationen eines Fahrers an.",
)
@app_commands.describe(
    fahrer="Discord-Mitglied, dessen Informationen angezeigt werden sollen"
)
@app_commands.guild_only()
async def driverinfo(
    interaction: discord.Interaction,
    fahrer: discord.Member,
) -> None:
    data = load_data()
    drivers = get_guild_drivers(data, interaction.guild_id)
    driver = find_driver(drivers, fahrer.id)

    if not driver:
        await interaction.response.send_message(
            f"❌ **{fahrer.display_name}** ist nicht im Fahrermarkt eingetragen.",
            ephemeral=True,
        )
        return

    embed = discord.Embed(
        title=f"🏎️ FAHRERPROFIL • {driver['name']}",
        description=f"{fahrer.mention}\n\n**Team:** {team_display(driver['team'])}",
        color=TEAM_COLORS.get(driver["team"], BRAND_COLOR),
    )
    embed.set_thumbnail(url=fahrer.display_avatar.url)

    embed.add_field(
        name="💰 Marktwert",
        value=driver["market_value"],
        inline=True,
    )
    embed.add_field(
        name="📄 Vertrag",
        value=driver["contract"],
        inline=True,
    )
    embed.add_field(
        name="🔓 Ausstiegsklausel",
        value=driver["release_clause"],
        inline=True,
    )
    embed.add_field(
        name="💵 Gehalt",
        value=driver["salary"],
        inline=True,
    )
    embed.add_field(
        name="🎯 Boni",
        value=driver["bonuses"],
        inline=True,
    )
    embed.set_footer(text=footer_text(data, interaction.guild_id))

    await interaction.response.send_message(embed=embed)


@bot.tree.command(
    name="topmarketvalue",
    description="Zeigt die Fahrer mit dem höchsten Marktwert.",
)
@app_commands.guild_only()
async def topmarketvalue(interaction: discord.Interaction) -> None:
    data = load_data()
    drivers = get_guild_drivers(data, interaction.guild_id)

    if not drivers:
        await interaction.response.send_message("Die Fahrerliste ist noch leer.")
        return

    ranked = sorted(
        drivers,
        key=lambda d: parse_market_value(d.get("market_value", "")),
        reverse=True,
    )[:10]

    medals = ["🥇", "🥈", "🥉"]
    lines = []

    for index, driver in enumerate(ranked, start=1):
        icon = medals[index - 1] if index <= 3 else f"**{index}.**"
        lines.append(
            f"{icon} **{driver['name']}** — "
            f"💰 **{driver['market_value']}**\n"
            f"└ {team_display(driver['team'])}"
        )

    embed = discord.Embed(
        title="💰 TOP MARKET VALUE",
        description="\n\n".join(lines),
        color=GOLD_COLOR,
    )
    embed.set_footer(text=footer_text(data, interaction.guild_id))

    await interaction.response.send_message(embed=embed)


@bot.tree.command(
    name="driverhistory",
    description="Zeigt die bisherige Historie eines Fahrers.",
)
@app_commands.describe(fahrer="Fahrer, dessen Historie angezeigt werden soll")
@app_commands.guild_only()
async def driverhistory(
    interaction: discord.Interaction,
    fahrer: discord.Member,
) -> None:
    data = load_data()
    drivers = get_guild_drivers(data, interaction.guild_id)
    driver = find_driver(drivers, fahrer.id)

    if not driver:
        await interaction.response.send_message(
            f"❌ **{fahrer.display_name}** ist nicht im Fahrermarkt eingetragen.",
            ephemeral=True,
        )
        return

    history = ensure_driver_history(driver)

    if not history:
        description = "Für diesen Fahrer gibt es noch keine gespeicherte Historie."
    else:
        entries = history[-15:][::-1]
        description = "\n\n".join(
            f"<t:{entry['timestamp']}:d> • {entry['text']}"
            for entry in entries
        )

    embed = discord.Embed(
        title=f"📚 DRIVER HISTORY • {driver['name']}",
        description=description,
        color=PUBLIC_COLOR,
    )
    embed.set_thumbnail(url=fahrer.display_avatar.url)
    embed.set_footer(
        text=f"{footer_text(data, interaction.guild_id)} • Letzte 15 Einträge"
    )

    await interaction.response.send_message(embed=embed)


@bot.tree.command(
    name="transfers",
    description="Zeigt die letzten Transfers der Liga.",
)
@app_commands.guild_only()
async def transfers(interaction: discord.Interaction) -> None:
    data = load_data()
    history = get_guild_transfers(data, interaction.guild_id)

    if not history:
        await interaction.response.send_message(
            "🔄 Es wurden noch keine Transfers gespeichert."
        )
        return

    entries = history[-15:][::-1]
    lines = []

    for item in entries:
        lines.append(
            f"🔄 **{item['name']}**\n"
            f"└ {item['from']} → **{item['to']}** "
            f"• Saison {item.get('season', '?')} "
            f"• <t:{item['timestamp']}:d>"
        )

    embed = discord.Embed(
        title="🔄 LETZTE TRANSFERS",
        description="\n\n".join(lines),
        color=BRAND_COLOR,
    )
    embed.set_footer(
        text=f"{footer_text(data, interaction.guild_id)} • Letzte 15 Transfers"
    )

    await interaction.response.send_message(embed=embed)



@bot.tree.command(
    name="help",
    description="Zeigt alle verfügbaren Commands und deren Berechtigungen.",
)
@app_commands.guild_only()
async def help_command(interaction: discord.Interaction) -> None:
    member = interaction.user

    has_transfer_role = False
    is_admin = False

    if isinstance(member, discord.Member):
        has_transfer_role = any(
            role.id == TRANSFER_ADMIN_ROLE_ID
            for role in member.roles
        )
        is_admin = is_real_admin(interaction)

    access_lines = [
        "✅ Öffentliche Commands",
        (
            "✅ Transferleitung"
            if has_transfer_role
            else "❌ Transferleitung"
        ),
        (
            "✅ Administrator / Owner"
            if is_admin
            else "❌ Administrator / Owner"
        ),
    ]

    embed = discord.Embed(
        title="📖 WTV DRIVER MARKET • HELP",
        description=(
            "Hier findest du alle Commands und wer sie benutzen darf.\n\n"
            "**Dein Zugriff:**\n"
            + "\n".join(access_lines)
        ),
        color=PUBLIC_COLOR,
    )

    embed.add_field(
        name="🌍 Öffentliche Commands",
        value=(
            "`/drivermarket` – Fahrermarkt nach Teams\n"
            "`/alldrivers` – alle Fahrer kompakt\n"
            "`/driverinfo` – Details zu einem Fahrer\n"
            "`/topmarketvalue` – höchste Marktwerte\n"
            "`/driverhistory` – Historie eines Fahrers\n"
            "`/transfers` – letzte Transfers\n"
            "`/help` – diese Übersicht"
        ),
        inline=False,
    )

    embed.add_field(
        name="🔐 Nur Transferleitung",
        value=(
            "`/adddriver` – Fahrer hinzufügen/aktualisieren\n"
            "`/editdriver` – einzelne Fahrerdaten ändern\n"
            "`/transferdriver` – Fahrer transferieren\n"
            "`/removedriver` – Fahrer komplett entfernen\n"
            "`/renewcontract` – Vertrag verlängern\n"
            "`/setmarketvalue` – Marktwert ändern\n"
            "`/botstatus` – Bot- und Serverstatus anzeigen"
        ),
        inline=False,
    )

    embed.add_field(
        name="🛡️ Nur Administrator / Owner",
        value=(
            "`/saison` – aktuelle Saisonnummer direkt setzen\n"
            "`/newseason` – neue Saison starten\n"
            "`/undoseason` – letzten Saisonwechsel rückgängig machen"
        ),
        inline=False,
    )

    embed.add_field(
        name="ℹ️ Rollenhinweis",
        value=(
            f"Transferleitung: <@&{TRANSFER_ADMIN_ROLE_ID}>\n"
            "Für automatische Teamwechsel braucht **der Bot selbst** "
            "weiterhin die Berechtigung **Rollen verwalten**."
        ),
        inline=False,
    )

    data = load_data()
    embed.set_footer(
        text=f"{footer_text(data, interaction.guild_id)} • Hilfe"
    )

    await interaction.response.send_message(embed=embed)


# =========================================================
# TRANSFERLEITUNG / VERWALTUNG
# =========================================================

@bot.tree.command(
    name="adddriver",
    description="Fügt einen Fahrer hinzu oder aktualisiert ihn.",
)
@app_commands.describe(
    fahrer="Discord-Mitglied",
    marktwert="z. B. 25 Mio. €",
    vertrag="Empfohlen: z. B. 2 Saisons",
    ausstiegsklausel="z. B. 40 Mio. € oder Keine",
    gehalt="z. B. 8 Mio. €/Saison oder -",
    boni="z. B. 1 Mio. € pro Sieg, Keine oder -",
)
@transfer_staff_only()
@app_commands.guild_only()
async def adddriver(
    interaction: discord.Interaction,
    fahrer: discord.Member,
    marktwert: str,
    vertrag: str,
    ausstiegsklausel: str,
    gehalt: str,
    boni: str,
) -> None:
    team = get_team_from_member(fahrer)

    async with data_lock:
        data = load_data()
        drivers = get_guild_drivers(data, interaction.guild_id)
        existing = find_driver(drivers, fahrer.id)

        if existing:
            old_snapshot = (
                existing.get("market_value"),
                existing.get("contract"),
                existing.get("release_clause"),
                existing.get("salary"),
                existing.get("bonuses"),
                existing.get("team"),
            )

            existing.update({
                "name": fahrer.display_name,
                "team": team,
                "market_value": marktwert.strip(),
                "contract": vertrag.strip(),
                "release_clause": ausstiegsklausel.strip(),
                "salary": gehalt.strip(),
                "bonuses": boni.strip(),
            })
            ensure_driver_history(existing)
            add_driver_history(
                existing,
                "✏️ Fahrerdaten über `/adddriver` aktualisiert.",
            )
            driver = existing
            action = "aktualisiert"
        else:
            driver = {
                "user_id": fahrer.id,
                "name": fahrer.display_name,
                "team": team,
                "market_value": marktwert.strip(),
                "contract": vertrag.strip(),
                "release_clause": ausstiegsklausel.strip(),
                "salary": gehalt.strip(),
                "bonuses": boni.strip(),
                "history": [],
            }
            add_driver_history(driver, "➕ Fahrer zum Fahrermarkt hinzugefügt.")
            drivers.append(driver)
            action = "hinzugefügt"

        save_data(data)

    embed = discord.Embed(
        title=f"✅ Fahrer {action}",
        description=(
            f"**{fahrer.display_name}**\n"
            f"**Team:** {team_display(team)}"
        ),
        color=SUCCESS_COLOR,
    )
    await interaction.response.send_message(embed=embed, ephemeral=True)


@bot.tree.command(
    name="editdriver",
    description="Ändert einzelne Daten eines Fahrers.",
)
@app_commands.describe(
    fahrer="Fahrer, dessen Daten geändert werden sollen",
    marktwert="Leer lassen = unverändert",
    vertrag="Leer lassen = unverändert",
    ausstiegsklausel="Leer lassen = unverändert",
    gehalt="Leer lassen = unverändert",
    boni="Leer lassen = unverändert",
)
@transfer_staff_only()
@app_commands.guild_only()
async def editdriver(
    interaction: discord.Interaction,
    fahrer: discord.Member,
    marktwert: str | None = None,
    vertrag: str | None = None,
    ausstiegsklausel: str | None = None,
    gehalt: str | None = None,
    boni: str | None = None,
) -> None:
    changes = []

    async with data_lock:
        data = load_data()
        drivers = get_guild_drivers(data, interaction.guild_id)
        driver = find_driver(drivers, fahrer.id)

        if not driver:
            await interaction.response.send_message(
                f"❌ **{fahrer.display_name}** ist nicht im Fahrermarkt.",
                ephemeral=True,
            )
            return

        driver["name"] = fahrer.display_name

        fields = [
            ("market_value", marktwert, "Marktwert"),
            ("contract", vertrag, "Vertrag"),
            ("release_clause", ausstiegsklausel, "Ausstiegsklausel"),
            ("salary", gehalt, "Gehalt"),
            ("bonuses", boni, "Boni"),
        ]

        history_changes = []

        for key, new_value, label in fields:
            if new_value is not None and new_value.strip():
                old_value = driver.get(key, "–")
                new_value = new_value.strip()

                if old_value != new_value:
                    driver[key] = new_value
                    changes.append(f"**{label}:** {new_value}")
                    history_changes.append(
                        f"{label}: {old_value} → {new_value}"
                    )

        if not changes:
            await interaction.response.send_message(
                "❌ Du hast keine neuen Werte angegeben.",
                ephemeral=True,
            )
            return

        add_driver_history(
            driver,
            "✏️ Bearbeitet: " + " | ".join(history_changes),
        )
        save_data(data)

    embed = discord.Embed(
        title="✏️ Fahrer aktualisiert",
        description=f"**{fahrer.display_name}**\n\n" + "\n".join(changes),
        color=SUCCESS_COLOR,
    )
    await interaction.response.send_message(embed=embed, ephemeral=True)


@bot.tree.command(
    name="transferdriver",
    description="Transferiert einen Fahrer zu einem anderen Team oder auf Frei.",
)
@app_commands.describe(
    fahrer="Fahrer, der transferiert werden soll",
    neues_team="Neues Team oder Frei / Free Agent",
    marktwert="Optional: neuer Marktwert",
    vertrag="Optional: neuer Vertrag",
    ausstiegsklausel="Optional: neue Ausstiegsklausel",
    gehalt="Optional: neues Gehalt",
    boni="Optional: neue Boni",
)
@app_commands.choices(neues_team=TRANSFER_TEAM_CHOICES)
@transfer_staff_only()
@app_commands.guild_only()
async def transferdriver(
    interaction: discord.Interaction,
    fahrer: discord.Member,
    neues_team: app_commands.Choice[str],
    marktwert: str | None = None,
    vertrag: str | None = None,
    ausstiegsklausel: str | None = None,
    gehalt: str | None = None,
    boni: str | None = None,
) -> None:
    data = load_data()
    drivers = get_guild_drivers(data, interaction.guild_id)
    driver = find_driver(drivers, fahrer.id)

    if not driver:
        await interaction.response.send_message(
            f"❌ **{fahrer.display_name}** ist nicht im Fahrermarkt.",
            ephemeral=True,
        )
        return

    old_team = driver["team"]
    target_team = neues_team.value

    role_ok, role_error = await change_member_team_role(fahrer, target_team)

    if not role_ok:
        await interaction.response.send_message(
            f"❌ Transfer nicht durchgeführt.\n{role_error}",
            ephemeral=True,
        )
        return

    async with data_lock:
        data = load_data()
        drivers = get_guild_drivers(data, interaction.guild_id)
        driver = find_driver(drivers, fahrer.id)

        if not driver:
            await interaction.response.send_message(
                "❌ Fahrer wurde zwischenzeitlich entfernt.",
                ephemeral=True,
            )
            return

        driver["name"] = fahrer.display_name
        driver["team"] = target_team

        optional_changes = [
            ("market_value", marktwert),
            ("contract", vertrag),
            ("release_clause", ausstiegsklausel),
            ("salary", gehalt),
            ("bonuses", boni),
        ]

        for key, value in optional_changes:
            if value is not None and value.strip():
                driver[key] = value.strip()

        add_driver_history(
            driver,
            f"🔄 Transfer: {old_team} → {target_team}",
        )
        add_transfer_history(
            data,
            interaction.guild_id,
            driver,
            old_team,
            target_team,
        )
        save_data(data)

    embed = discord.Embed(
        title="🔄 TRANSFER DURCHGEFÜHRT",
        description=(
            f"**Fahrer:** {fahrer.mention}\n"
            f"**Von:** {team_display(old_team)}\n"
            f"**Zu:** {team_display(target_team)}"
        ),
        color=SUCCESS_COLOR,
    )
    await interaction.response.send_message(embed=embed, ephemeral=True)


@bot.tree.command(
    name="removedriver",
    description="Entfernt einen Fahrer komplett aus dem Fahrermarkt.",
)
@app_commands.describe(
    fahrer="Discord-Mitglied, das komplett entfernt werden soll"
)
@transfer_staff_only()
@app_commands.guild_only()
async def removedriver(
    interaction: discord.Interaction,
    fahrer: discord.Member,
) -> None:
    async with data_lock:
        data = load_data()
        drivers = get_guild_drivers(data, interaction.guild_id)
        before = len(drivers)
        drivers[:] = [d for d in drivers if d["user_id"] != fahrer.id]

        if len(drivers) == before:
            await interaction.response.send_message(
                f"❌ **{fahrer.display_name}** ist nicht im Fahrermarkt.",
                ephemeral=True,
            )
            return

        save_data(data)

    embed = discord.Embed(
        title="🗑️ Fahrer entfernt",
        description=(
            f"**{fahrer.display_name}** wurde komplett "
            "aus dem Fahrermarkt entfernt."
        ),
        color=DANGER_COLOR,
    )
    await interaction.response.send_message(embed=embed, ephemeral=True)


@bot.tree.command(
    name="renewcontract",
    description="Verlängert bzw. erneuert den Vertrag eines Fahrers.",
)
@app_commands.describe(
    fahrer="Fahrer, dessen Vertrag verlängert wird",
    vertrag="Neuer Vertrag, empfohlen z. B. 2 Saisons",
    ausstiegsklausel="Optional: neue Ausstiegsklausel",
    gehalt="Optional: neues Gehalt",
    boni="Optional: neue Boni",
)
@transfer_staff_only()
@app_commands.guild_only()
async def renewcontract(
    interaction: discord.Interaction,
    fahrer: discord.Member,
    vertrag: str,
    ausstiegsklausel: str | None = None,
    gehalt: str | None = None,
    boni: str | None = None,
) -> None:
    async with data_lock:
        data = load_data()
        drivers = get_guild_drivers(data, interaction.guild_id)
        driver = find_driver(drivers, fahrer.id)

        if not driver:
            await interaction.response.send_message(
                f"❌ **{fahrer.display_name}** ist nicht im Fahrermarkt.",
                ephemeral=True,
            )
            return

        old_contract = driver["contract"]
        driver["contract"] = vertrag.strip()

        details = [f"📄 **Vertrag:** {old_contract} → {driver['contract']}"]

        if ausstiegsklausel is not None and ausstiegsklausel.strip():
            driver["release_clause"] = ausstiegsklausel.strip()
            details.append(
                f"🔓 **Ausstiegsklausel:** {driver['release_clause']}"
            )

        if gehalt is not None and gehalt.strip():
            driver["salary"] = gehalt.strip()
            details.append(f"💵 **Gehalt:** {driver['salary']}")

        if boni is not None and boni.strip():
            driver["bonuses"] = boni.strip()
            details.append(f"🎯 **Boni:** {driver['bonuses']}")

        add_driver_history(
            driver,
            f"📝 Vertragsverlängerung: {old_contract} → {driver['contract']}",
        )
        save_data(data)

    embed = discord.Embed(
        title="📝 VERTRAG VERLÄNGERT",
        description=f"**{fahrer.display_name}**\n\n" + "\n".join(details),
        color=SUCCESS_COLOR,
    )
    await interaction.response.send_message(embed=embed, ephemeral=True)


@bot.tree.command(
    name="setmarketvalue",
    description="Setzt den Marktwert eines Fahrers.",
)
@app_commands.describe(
    fahrer="Fahrer, dessen Marktwert geändert wird",
    marktwert="Neuer Marktwert, z. B. 25 Mio. €",
)
@transfer_staff_only()
@app_commands.guild_only()
async def setmarketvalue(
    interaction: discord.Interaction,
    fahrer: discord.Member,
    marktwert: str,
) -> None:
    async with data_lock:
        data = load_data()
        drivers = get_guild_drivers(data, interaction.guild_id)
        driver = find_driver(drivers, fahrer.id)

        if not driver:
            await interaction.response.send_message(
                f"❌ **{fahrer.display_name}** ist nicht im Fahrermarkt.",
                ephemeral=True,
            )
            return

        old_value = driver["market_value"]
        new_value = marktwert.strip()
        driver["market_value"] = new_value

        add_driver_history(
            driver,
            f"💰 Marktwert: {old_value} → {new_value}",
        )
        save_data(data)

    embed = discord.Embed(
        title="💰 MARKTWERT AKTUALISIERT",
        description=(
            f"**{fahrer.display_name}**\n\n"
            f"{old_value} → **{new_value}**"
        ),
        color=SUCCESS_COLOR,
    )
    await interaction.response.send_message(embed=embed, ephemeral=True)



@bot.tree.command(
    name="botstatus",
    description="Zeigt Status und Server-Konfiguration des Bots.",
)
@transfer_staff_only()
@app_commands.guild_only()
async def botstatus(interaction: discord.Interaction) -> None:
    data = load_data()
    drivers = get_guild_drivers(data, interaction.guild_id)
    transfer_history = get_guild_transfers(data, interaction.guild_id)
    season = get_guild_season(data, interaction.guild_id)

    free_agents = sum(
        1
        for driver in drivers
        if driver.get("team", "").strip().lower() == "frei"
    )

    configured_team_roles = 0
    missing_team_roles = []

    for team_name, role_id in TEAM_ROLES.items():
        role = interaction.guild.get_role(role_id)
        if role is not None:
            configured_team_roles += 1
        else:
            missing_team_roles.append(team_name)

    transfer_role = interaction.guild.get_role(TRANSFER_ADMIN_ROLE_ID)
    storage_ok = DATA_DIR.exists()

    embed = discord.Embed(
        title="🛠️ WTV DRIVER MARKET • BOTSTATUS",
        description=(
            "Aktueller Status des Bots und der wichtigsten "
            "Server-Konfiguration."
        ),
        color=SUCCESS_COLOR if storage_ok else WARNING_COLOR,
    )

    embed.add_field(name="🟢 Bot", value="Online", inline=True)
    embed.add_field(name="🏁 Saison", value=str(season), inline=True)
    embed.add_field(name="👥 Fahrer", value=str(len(drivers)), inline=True)
    embed.add_field(name="🆓 Freie Fahrer", value=str(free_agents), inline=True)
    embed.add_field(
        name="🔄 Gespeicherte Transfers",
        value=str(len(transfer_history)),
        inline=True,
    )
    embed.add_field(
        name="💾 Datenspeicher",
        value="✅ OK" if storage_ok else "⚠️ Problem",
        inline=True,
    )
    embed.add_field(
        name="🏎️ Teamrollen",
        value=f"{configured_team_roles}/{len(TEAM_ROLES)} erkannt",
        inline=True,
    )
    embed.add_field(
        name="🔐 Transferleitung",
        value=(
            f"✅ {transfer_role.mention}"
            if transfer_role is not None
            else f"❌ Rolle `{TRANSFER_ADMIN_ROLE_ID}` nicht gefunden"
        ),
        inline=True,
    )

    if missing_team_roles:
        embed.add_field(
            name="⚠️ Fehlende Teamrollen",
            value=", ".join(missing_team_roles),
            inline=False,
        )

    embed.add_field(
        name="📁 Speicherpfad",
        value=f"`{DATA_FILE}`",
        inline=False,
    )

    embed.set_footer(
        text=f"{footer_text(data, interaction.guild_id)} • Nur Transferleitung"
    )

    await interaction.response.send_message(embed=embed, ephemeral=True)


# =========================================================
# ADMINISTRATOR-ONLY
# =========================================================

@bot.tree.command(
    name="saison",
    description="Setzt die aktuelle Saisonnummer direkt, ohne Verträge zu verändern.",
)
@app_commands.describe(
    nummer="Saisonnummer, z. B. 6"
)
@administrator_only()
@app_commands.guild_only()
async def saison(
    interaction: discord.Interaction,
    nummer: app_commands.Range[int, 1, 999],
) -> None:
    async with data_lock:
        data = load_data()
        old_season = get_guild_season(data, interaction.guild_id)
        set_guild_season(data, interaction.guild_id, nummer)
        save_data(data)

    embed = discord.Embed(
        title="🏁 SAISON GESETZT",
        description=(
            f"**Saison {old_season} → Saison {nummer}**\\n\\n"
            "Die Saisonnummer wurde direkt geändert. "
            "**Vertragslaufzeiten wurden dabei nicht verändert.**"
        ),
        color=SUCCESS_COLOR,
    )

    embed.set_footer(
        text=f"WTV Driver Market • Saison {nummer}"
    )

    await interaction.response.send_message(
        embed=embed,
        ephemeral=True,
    )


@bot.tree.command(
    name="newseason",
    description="Startet eine neue Saison und reduziert Vertragslaufzeiten.",
)
@administrator_only()
@app_commands.guild_only()
async def newseason(interaction: discord.Interaction) -> None:
    data = load_data()
    season = get_guild_season(data, interaction.guild_id)

    embed = discord.Embed(
        title="⚠️ NEUE SAISON STARTEN?",
        description=(
            f"Aktuell: **Saison {season}**\n"
            f"Danach: **Saison {season + 1}**\n\n"
            "Bei Verträgen im Format `2 Saisons`, `1 Saison` oder `2` "
            "wird die Laufzeit um **1** reduziert.\n\n"
            "Vorher wird automatisch ein Undo-Stand gespeichert."
        ),
        color=WARNING_COLOR,
    )

    view = NewSeasonConfirmView(
        interaction.user.id,
        interaction.guild_id,
    )
    await interaction.response.send_message(
        embed=embed,
        view=view,
        ephemeral=True,
    )


@bot.tree.command(
    name="undoseason",
    description="Macht den letzten Saisonwechsel rückgängig.",
)
@administrator_only()
@app_commands.guild_only()
async def undoseason(interaction: discord.Interaction) -> None:
    data = load_data()
    backup = get_season_backup(data, interaction.guild_id)

    if not backup:
        await interaction.response.send_message(
            "❌ Es gibt aktuell keinen gespeicherten Saisonwechsel zum Rückgängigmachen.",
            ephemeral=True,
        )
        return

    current_season = get_guild_season(data, interaction.guild_id)
    previous_season = int(backup.get("previous_season", 1))

    embed = discord.Embed(
        title="⚠️ SAISONWECHSEL RÜCKGÄNGIG MACHEN?",
        description=(
            f"**Saison {current_season} → Saison {previous_season}**\n\n"
            "Die Vertragslaufzeiten werden auf den Stand direkt vor "
            "dem letzten `/newseason` zurückgesetzt."
        ),
        color=WARNING_COLOR,
    )

    view = UndoSeasonConfirmView(
        interaction.user.id,
        interaction.guild_id,
    )
    await interaction.response.send_message(
        embed=embed,
        view=view,
        ephemeral=True,
    )


# =========================================================
# FEHLERBEHANDLUNG
# =========================================================

@bot.tree.error
async def on_app_command_error(
    interaction: discord.Interaction,
    error: app_commands.AppCommandError,
) -> None:
    if isinstance(error, TransferPermissionError):
        message = (
            "🔒 Du hast keine Berechtigung für diesen Command. "
            f"Benötigte Rolle: <@&{TRANSFER_ADMIN_ROLE_ID}>"
        )

    elif isinstance(error, AdministratorPermissionError):
        message = (
            "🔒 Dieser Command kann nur von einem echten "
            "**Discord-Administrator oder dem Server-Owner** benutzt werden."
        )

    elif isinstance(error, app_commands.CommandInvokeError):
        print(f"Command-Fehler: {repr(error.original)}")
        message = "❌ Beim Ausführen des Commands ist ein Fehler aufgetreten."

    else:
        print(f"Command-Fehler: {repr(error)}")
        message = "❌ Beim Ausführen des Commands ist ein Fehler aufgetreten."

    if interaction.response.is_done():
        await interaction.followup.send(message, ephemeral=True)
    else:
        await interaction.response.send_message(message, ephemeral=True)


@bot.event
async def on_ready() -> None:
    print(f"Bot ist online als {bot.user}.")
    print(f"Datendatei: {DATA_FILE.resolve()}")
    print(f"Transferleitung Rollen-ID: {TRANSFER_ADMIN_ROLE_ID}")


if not TOKEN:
    raise RuntimeError("DISCORD_TOKEN fehlt.")

bot.run(TOKEN)
