# WTV Driver Market V3

## Commands

Öffentlich:
- /drivermarket
- /alldrivers
- /driverinfo
- /topmarketvalue
- /driverhistory
- /transfers

Transferleitung / Discord-Admin:
- /adddriver
- /editdriver
- /transferdriver
- /removedriver
- /renewcontract
- /setmarketvalue

Nur Discord-Administrator / Server-Owner:
- /newseason
- /undoseason

## Railway Variablen

Pflicht:
- DISCORD_TOKEN
- GUILD_ID

Für die eigene Transferleitungs-Rolle:
- TRANSFER_ADMIN_ROLE_ID

Dafür wird nur die Rollen-ID benötigt, nicht der Rollenname.

## Saison-System

/newseason reduziert Verträge nur bei Formaten wie:
- 3
- 3 Saisons
- 1 Saison

Freitext wie "bis Ende 2027" bleibt unverändert.

/undoseason stellt die Vertragswerte des letzten Saisonwechsels wieder her.

## Wichtig

Für /transferdriver braucht der Bot selbst:
- Rollen verwalten
- Bot-Rolle über den Teamrollen
