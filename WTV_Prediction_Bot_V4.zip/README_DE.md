# WTV Prediction Bot V4

## Die zwei großen Änderungen aus V4

### 1. Keine manuelle Fahrerliste mehr

Diese Commands wurden entfernt:

- `/addpredictiondriver`
- `/editpredictiondriver`
- `/removepredictiondriver`
- `/predictiondrivers`

Bei `/predict` wählst du stattdessen direkt Discord-Mitglieder aus.

Beispiel:

- Pole -> Discord-Mitglied auswählen
- P1 -> Discord-Mitglied auswählen
- P2 -> Discord-Mitglied auswählen
- P3 -> Discord-Mitglied auswählen
- Fastest Lap -> Discord-Mitglied auswählen
- DNF -> optional Discord-Mitglied auswählen

Der Bot speichert intern Discord-ID + Servername.
Bots werden als Fahrer nicht akzeptiert.

Vorteil:
Ein neuer Fahrer auf dem Discord-Server ist sofort auswählbar.
Niemand muss vorher eine Bot-Fahrerliste pflegen.

Hinweis:
V4 kennt bewusst keine spezielle Fahrer-Rolle.
Damit sind alle menschlichen Servermitglieder auswählbar.
Eine spätere Version kann auf Wunsch nur Mitglieder einer Rolle wie
"Fahrer" oder Teamrollen zulassen.

---

## 2. Deadline ist optional

Bei:

`/newprediction`

sind nur diese Angaben nötig:

- Grand Prix
- Sprint: Ja/Nein

`deadline` ist OPTIONAL.

### Ohne Deadline

Deadline leer lassen.

Dann:

- keine automatischen Erinnerungen
- keine automatische Schließung
- Prediction bleibt offen

Bis die Predictionleitung:

`/closeprediction`

oder:

`/setpredictionresult`

verwendet.

### Mit Deadline

Format:

`TT.MM.JJJJ HH:MM`

Beispiel:

`06.09.2026 14:55`

Dann:

- österreichische Zeit (Europe/Vienna)
- Reminder 60 Minuten vorher
- Reminder 15 Minuten vorher
- automatische Schließung zur Deadline

---

# Predictions

Hauptrennen:

- Pole
- P1
- P2
- P3
- Fastest Lap
- optional ein DNF-Fahrer
- Safety Car Ja/Nein

DNF leer lassen = Prediction "Kein DNF".

---

# Sprint

Bei `/newprediction`:

Sprint:
- Nein
- Ja

Bei Nein:
Sprint-Felder werden bei `/predict` ignoriert und müssen nicht ausgefüllt werden.

Bei Ja:
- Sprint P1
- Sprint P2
- Sprint P3

müssen ausgewählt werden.

---

# Bonusfragen

Predictionleitung:

`/addbonusquestion`

Beispiel:

Frage:
`Gibt es eine rote Flagge?`

Option A:
`Ja`

Option B:
`Nein`

Punkte:
`3`

Mitglieder antworten mit:

`/bonuspredict`

Nach dem Rennen:

`/setbonusanswer`

---

# Commands

## Öffentlich

- `/predict`
- `/bonuspredict`
- `/myprediction`
- `/predictioninfo`
- `/predictionstandings`
- `/predictionhistory`
- `/bonusquestions`
- `/predictionhelp`

## Predictionleitung / Admin

- `/newprediction`
- `/addbonusquestion`
- `/setbonusanswer`
- `/closeprediction`
- `/setpredictionresult`
- `/allpredictions`
- `/deletepredictionround`

---

# Railway

Variables:

```text
DISCORD_TOKEN=DEIN_TOKEN
GUILD_ID=DEINE_SERVER_ID
PREDICTION_ROLE_NAME=Predictionleitung
DB_PATH=/data/predictions.db
```

Railway Volume:

```text
/data
```

Start Command:

```text
python bot.py
```

---

# Update von V3

V4 benutzt die bestehende SQLite-Datenbank weiter.

Die alte `drivers`-Tabelle wird aus Kompatibilitätsgründen nicht gelöscht,
aber V4 benutzt sie nicht mehr.

Alte bereits gespeicherte Fahrer-Namen aus V2/V3 können in historischen
Predictions weiterhin angezeigt werden.

Vor einem Update mit echten Liga-Daten trotzdem immer ein Backup der
`predictions.db` machen.
