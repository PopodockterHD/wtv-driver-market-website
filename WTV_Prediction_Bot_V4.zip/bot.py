import os
import sqlite3
import asyncio
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
from typing import Optional

import discord
from discord import app_commands
from discord.ext import commands, tasks


# ============================================================
# WTV Prediction Bot V4
# ============================================================
# V4:
# - KEINE manuelle Fahrerliste mehr
# - Fahrer werden direkt als Discord-Mitglieder ausgewählt
# - Bots werden als Fahrer abgelehnt
# - Deadline ist optional
# - Ohne Deadline: offen bis /closeprediction oder Auswertung
# - Mit Deadline: automatische Schließung + Erinnerungen
# - Pole, Podium, Fastest Lap, DNF, Safety Car
# - optionales Sprint-Wochenende
# - Bonusfragen
# - Gesamtwertung + Historie
# ============================================================

TOKEN = os.getenv("DISCORD_TOKEN")
GUILD_ID = os.getenv("GUILD_ID")
MANAGER_ROLE_NAME = os.getenv("PREDICTION_ROLE_NAME", "Predictionleitung")
DB_PATH = os.getenv("DB_PATH", "predictions.db")

VIENNA = ZoneInfo("Europe/Vienna")
EMBED_COLOR = 0xE10600

# Punkte Hauptrennen
POINTS_POLE = 5
POINTS_P1 = 10
POINTS_P2 = 8
POINTS_P3 = 6
POINTS_PODIUM_WRONG_POSITION = 2
POINTS_FASTEST_LAP = 4
POINTS_DNF = 4
POINTS_SAFETY_CAR = 3

# Sprint
POINTS_SPRINT_P1 = 6
POINTS_SPRINT_P2 = 4
POINTS_SPRINT_P3 = 3
POINTS_SPRINT_WRONG_POSITION = 1

# Erinnerungen bei gesetzter Deadline
REMINDER_1_MINUTES = 60
REMINDER_2_MINUTES = 15

intents = discord.Intents.default()
bot = commands.Bot(command_prefix="!", intents=intents)
tree = bot.tree
db_lock = asyncio.Lock()


# ============================================================
# DB
# ============================================================

def get_db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con


def table_columns(con, table):
    return {r["name"] for r in con.execute(f"PRAGMA table_info({table})").fetchall()}


def add_column(con, table, column, definition):
    if column not in table_columns(con, table):
        con.execute(f"ALTER TABLE {table} ADD COLUMN {column} {definition}")


def init_db():
    with get_db() as con:
        # drivers bleibt für Kompatibilität zu V2/V3 bestehen,
        # wird von V4 aber NICHT mehr verwendet.
        con.execute("""
            CREATE TABLE IF NOT EXISTS drivers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                discord_user_id INTEGER,
                name TEXT NOT NULL UNIQUE COLLATE NOCASE,
                team TEXT,
                active INTEGER NOT NULL DEFAULT 1,
                created_at_utc TEXT NOT NULL
            )
        """)

        con.execute("""
            CREATE TABLE IF NOT EXISTS rounds (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                grand_prix TEXT NOT NULL,
                deadline_utc TEXT NOT NULL DEFAULT '',
                status TEXT NOT NULL DEFAULT 'OPEN',
                pole_result TEXT,
                p1_result TEXT,
                p2_result TEXT,
                p3_result TEXT,
                created_by INTEGER NOT NULL,
                created_at_utc TEXT NOT NULL,
                scored_at_utc TEXT
            )
        """)

        con.execute("""
            CREATE TABLE IF NOT EXISTS predictions (
                round_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                user_name TEXT NOT NULL,
                pole TEXT NOT NULL,
                p1 TEXT NOT NULL,
                p2 TEXT NOT NULL,
                p3 TEXT NOT NULL,
                submitted_at_utc TEXT NOT NULL,
                points INTEGER,
                PRIMARY KEY (round_id, user_id)
            )
        """)

        con.execute("""
            CREATE TABLE IF NOT EXISTS bonus_questions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                round_id INTEGER NOT NULL,
                question TEXT NOT NULL,
                option_a TEXT NOT NULL,
                option_b TEXT NOT NULL,
                points INTEGER NOT NULL DEFAULT 3,
                correct_answer TEXT,
                created_by INTEGER NOT NULL,
                created_at_utc TEXT NOT NULL
            )
        """)

        con.execute("""
            CREATE TABLE IF NOT EXISTS bonus_answers (
                question_id INTEGER NOT NULL,
                round_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                user_name TEXT NOT NULL,
                answer TEXT NOT NULL,
                points_earned INTEGER,
                submitted_at_utc TEXT NOT NULL,
                PRIMARY KEY (question_id, user_id)
            )
        """)

        # V2/V3 -> V4 Migration
        for column, definition in [
            ("fastest_lap_result", "TEXT"),
            ("dnf_result", "TEXT"),
            ("safety_car_result", "TEXT"),
            ("has_sprint", "INTEGER NOT NULL DEFAULT 0"),
            ("sprint_p1_result", "TEXT"),
            ("sprint_p2_result", "TEXT"),
            ("sprint_p3_result", "TEXT"),
            ("channel_id", "INTEGER"),
            ("reminder_60_sent", "INTEGER NOT NULL DEFAULT 0"),
            ("reminder_15_sent", "INTEGER NOT NULL DEFAULT 0"),
        ]:
            add_column(con, "rounds", column, definition)

        for column, definition in [
            ("fastest_lap", "TEXT"),
            ("dnf", "TEXT"),
            ("safety_car", "TEXT"),
            ("sprint_p1", "TEXT"),
            ("sprint_p2", "TEXT"),
            ("sprint_p3", "TEXT"),
        ]:
            add_column(con, "predictions", column, definition)

        con.commit()


# ============================================================
# Helpers
# ============================================================

def now_iso():
    return datetime.now(timezone.utc).isoformat()


def clean(value: Optional[str]) -> Optional[str]:
    if value is None:
        return None
    return " ".join(value.strip().split())


def norm(value: Optional[str]) -> str:
    return (clean(value) or "").casefold()


def parse_deadline(value: str) -> datetime:
    dt = datetime.strptime(value.strip(), "%d.%m.%Y %H:%M")
    return dt.replace(tzinfo=VIENNA)


def has_deadline(row: sqlite3.Row) -> bool:
    return bool(row["deadline_utc"] and str(row["deadline_utc"]).strip())


def discord_time(iso_value: str) -> str:
    dt = datetime.fromisoformat(iso_value).astimezone(timezone.utc)
    ts = int(dt.timestamp())
    return f"<t:{ts}:F> (<t:{ts}:R>)"


def make_embed(title: str, description: Optional[str] = None):
    return discord.Embed(title=title, description=description, color=EMBED_COLOR)


def pack_member(member: discord.Member) -> str:
    # ID bleibt für Vergleiche stabil, Name bleibt für Historie sichtbar.
    return f"{member.id}|{member.display_name}"


def unpack_member(value: Optional[str]) -> tuple[Optional[int], str]:
    if not value:
        return None, "—"
    text = str(value)
    if "|" in text:
        first, name = text.split("|", 1)
        try:
            return int(first), name
        except ValueError:
            pass
    # V2/V3-Kompatibilität: dort wurden nur Namen gespeichert.
    return None, text


def driver_name(value: Optional[str]) -> str:
    return unpack_member(value)[1]


def same_driver(a: Optional[str], b: Optional[str]) -> bool:
    a_id, a_name = unpack_member(a)
    b_id, b_name = unpack_member(b)

    if a_id is not None and b_id is not None:
        return a_id == b_id

    return norm(a_name) == norm(b_name)


def valid_human_member(member: Optional[discord.Member]) -> bool:
    return member is not None and not member.bot


def status_text(status: str) -> str:
    return {
        "OPEN": "🟢 Offen",
        "CLOSED": "🔒 Geschlossen",
        "SCORED": "✅ Ausgewertet",
    }.get(status, status)


def scoring_text(has_sprint: bool) -> str:
    result = (
        f"🎯 Pole: **{POINTS_POLE} P**\n"
        f"🥇 P1: **{POINTS_P1} P**\n"
        f"🥈 P2: **{POINTS_P2} P**\n"
        f"🥉 P3: **{POINTS_P3} P**\n"
        f"↔️ Podium richtige Person, falscher Platz: **{POINTS_PODIUM_WRONG_POSITION} P**\n"
        f"⚡ Fastest Lap: **{POINTS_FASTEST_LAP} P**\n"
        f"💥 DNF: **{POINTS_DNF} P**\n"
        f"🚨 Safety Car: **{POINTS_SAFETY_CAR} P**"
    )

    if has_sprint:
        result += (
            f"\n\n**Sprint:**\n"
            f"🥇 P1: **{POINTS_SPRINT_P1} P**\n"
            f"🥈 P2: **{POINTS_SPRINT_P2} P**\n"
            f"🥉 P3: **{POINTS_SPRINT_P3} P**\n"
            f"↔️ richtige Person, falscher Platz: **{POINTS_SPRINT_WRONG_POSITION} P**"
        )
    return result


async def current_round(include_scored: bool = False):
    async with db_lock:
        with get_db() as con:
            if include_scored:
                return con.execute(
                    "SELECT * FROM rounds ORDER BY id DESC LIMIT 1"
                ).fetchone()

            return con.execute(
                """
                SELECT * FROM rounds
                WHERE status IN ('OPEN','CLOSED')
                ORDER BY id DESC
                LIMIT 1
                """
            ).fetchone()


async def maybe_auto_close(row):
    if not row or row["status"] != "OPEN" or not has_deadline(row):
        return row

    deadline = datetime.fromisoformat(row["deadline_utc"]).astimezone(timezone.utc)
    if datetime.now(timezone.utc) < deadline:
        return row

    async with db_lock:
        with get_db() as con:
            con.execute("UPDATE rounds SET status='CLOSED' WHERE id=?", (row["id"],))
            con.commit()
            return con.execute("SELECT * FROM rounds WHERE id=?", (row["id"],)).fetchone()


# ============================================================
# Rechte
# ============================================================

def can_manage(member: discord.Member) -> bool:
    return (
        member.guild_permissions.administrator
        or any(role.name == MANAGER_ROLE_NAME for role in member.roles)
    )


async def require_manager(interaction: discord.Interaction) -> bool:
    if not isinstance(interaction.user, discord.Member) or not can_manage(interaction.user):
        message = (
            f"❌ Dafür brauchst du die Rolle **{MANAGER_ROLE_NAME}** "
            "oder Administrator-Rechte."
        )
        if interaction.response.is_done():
            await interaction.followup.send(message, ephemeral=True)
        else:
            await interaction.response.send_message(message, ephemeral=True)
        return False
    return True


# ============================================================
# Bonusfragen Autocomplete
# ============================================================

async def bonus_question_autocomplete(interaction, current):
    row = await current_round()
    if not row:
        return []

    async with db_lock:
        with get_db() as con:
            questions = con.execute(
                """
                SELECT id, question
                FROM bonus_questions
                WHERE round_id=?
                ORDER BY id
                """,
                (row["id"],),
            ).fetchall()

    q = current.casefold().strip()
    result = []
    for item in questions:
        label = f"{item['id']} · {item['question']}"
        if not q or q in label.casefold():
            result.append(
                app_commands.Choice(name=label[:100], value=str(item["id"]))
            )
    return result[:25]


async def bonus_answer_autocomplete(interaction, current):
    try:
        question_id = int(str(interaction.namespace.frage))
    except Exception:
        return []

    async with db_lock:
        with get_db() as con:
            qrow = con.execute(
                "SELECT option_a, option_b FROM bonus_questions WHERE id=?",
                (question_id,),
            ).fetchone()

    if not qrow:
        return []

    query = current.casefold().strip()
    options = [qrow["option_a"], qrow["option_b"]]
    return [
        app_commands.Choice(name=o[:100], value=o[:100])
        for o in options
        if not query or query in o.casefold()
    ][:25]


# ============================================================
# Punkte
# ============================================================

def score_prediction(pred: sqlite3.Row, result: sqlite3.Row) -> int:
    points = 0

    if same_driver(pred["pole"], result["pole_result"]):
        points += POINTS_POLE

    predicted = [pred["p1"], pred["p2"], pred["p3"]]
    actual = [result["p1_result"], result["p2_result"], result["p3_result"]]
    exact_points = [POINTS_P1, POINTS_P2, POINTS_P3]

    for i, predicted_driver in enumerate(predicted):
        if same_driver(predicted_driver, actual[i]):
            points += exact_points[i]
        elif any(same_driver(predicted_driver, x) for x in actual):
            points += POINTS_PODIUM_WRONG_POSITION

    if same_driver(pred["fastest_lap"], result["fastest_lap_result"]):
        points += POINTS_FASTEST_LAP

    # DNF: None/Kein DNF wird intern als leer gespeichert.
    pred_dnf = pred["dnf"] or ""
    result_dnf = result["dnf_result"] or ""
    if (
        (not pred_dnf and not result_dnf)
        or (pred_dnf and result_dnf and same_driver(pred_dnf, result_dnf))
    ):
        points += POINTS_DNF

    if norm(pred["safety_car"]) == norm(result["safety_car_result"]):
        points += POINTS_SAFETY_CAR

    if result["has_sprint"]:
        sprint_pred = [pred["sprint_p1"], pred["sprint_p2"], pred["sprint_p3"]]
        sprint_result = [
            result["sprint_p1_result"],
            result["sprint_p2_result"],
            result["sprint_p3_result"],
        ]
        sprint_exact = [POINTS_SPRINT_P1, POINTS_SPRINT_P2, POINTS_SPRINT_P3]

        for i, predicted_driver in enumerate(sprint_pred):
            if same_driver(predicted_driver, sprint_result[i]):
                points += sprint_exact[i]
            elif any(same_driver(predicted_driver, x) for x in sprint_result):
                points += POINTS_SPRINT_WRONG_POSITION

    return points


# ============================================================
# Erinnerungen
# ============================================================

async def post_reminder(row: sqlite3.Row, minutes: int):
    if not row["channel_id"]:
        return

    channel = bot.get_channel(int(row["channel_id"]))
    if channel is None:
        try:
            channel = await bot.fetch_channel(int(row["channel_id"]))
        except Exception:
            return

    e = make_embed(
        f"⏰ Noch {minutes} Minuten bis Tippschluss!",
        f"**{row['grand_prix']}**\n\nJetzt noch `/predict` verwenden oder den Tipp ändern.",
    )
    e.add_field(name="Deadline", value=discord_time(row["deadline_utc"]), inline=False)
    await channel.send(embed=e)


@tasks.loop(minutes=1)
async def reminder_loop():
    async with db_lock:
        with get_db() as con:
            rows = con.execute(
                "SELECT * FROM rounds WHERE status='OPEN'"
            ).fetchall()

    now = datetime.now(timezone.utc)

    for row in rows:
        # Keine Deadline = keine automatische Schließung/Erinnerungen.
        if not has_deadline(row):
            continue

        deadline = datetime.fromisoformat(row["deadline_utc"]).astimezone(timezone.utc)
        minutes_left = (deadline - now).total_seconds() / 60

        if minutes_left <= 0:
            async with db_lock:
                with get_db() as con:
                    con.execute(
                        "UPDATE rounds SET status='CLOSED' WHERE id=?",
                        (row["id"],),
                    )
                    con.commit()
            continue

        if minutes_left <= REMINDER_2_MINUTES and not row["reminder_15_sent"]:
            await post_reminder(row, REMINDER_2_MINUTES)
            async with db_lock:
                with get_db() as con:
                    con.execute(
                        "UPDATE rounds SET reminder_15_sent=1 WHERE id=?",
                        (row["id"],),
                    )
                    con.commit()

        elif minutes_left <= REMINDER_1_MINUTES and not row["reminder_60_sent"]:
            await post_reminder(row, REMINDER_1_MINUTES)
            async with db_lock:
                with get_db() as con:
                    con.execute(
                        "UPDATE rounds SET reminder_60_sent=1 WHERE id=?",
                        (row["id"],),
                    )
                    con.commit()


@reminder_loop.before_loop
async def before_reminder_loop():
    await bot.wait_until_ready()


# ============================================================
# Events
# ============================================================

@bot.event
async def setup_hook():
    init_db()

    if GUILD_ID:
        guild = discord.Object(id=int(GUILD_ID))
        tree.copy_global_to(guild=guild)
        synced = await tree.sync(guild=guild)
        print(f"✅ {len(synced)} Commands auf Guild {GUILD_ID} synchronisiert.")
    else:
        synced = await tree.sync()
        print(f"✅ {len(synced)} globale Commands synchronisiert.")


@bot.event
async def on_ready():
    print(f"🏁 WTV Prediction Bot V4 online als {bot.user} ({bot.user.id})")
    if not reminder_loop.is_running():
        reminder_loop.start()


# ============================================================
# Prediction erstellen
# ============================================================

@tree.command(name="newprediction", description="Erstellt eine neue Prediction-Runde.")
@app_commands.describe(
    grand_prix="z. B. Niederlande GP",
    sprint="Gibt es bei diesem Wochenende einen Sprint?",
    deadline="Optional: TT.MM.JJJJ HH:MM – leer lassen = keine Deadline",
    erinnerungs_channel="Optional: Channel für automatische Erinnerungen",
)
@app_commands.choices(
    sprint=[
        app_commands.Choice(name="Nein", value=0),
        app_commands.Choice(name="Ja", value=1),
    ]
)
async def newprediction(
    interaction: discord.Interaction,
    grand_prix: str,
    sprint: app_commands.Choice[int],
    deadline: Optional[str] = None,
    erinnerungs_channel: Optional[discord.TextChannel] = None,
):
    if not await require_manager(interaction):
        return

    existing = await current_round()
    if existing:
        existing = await maybe_auto_close(existing)
        if existing and existing["status"] in ("OPEN", "CLOSED"):
            await interaction.response.send_message(
                f"❌ **{existing['grand_prix']}** ist noch nicht ausgewertet.",
                ephemeral=True,
            )
            return

    deadline_utc = ""

    if deadline and deadline.strip():
        try:
            local_deadline = parse_deadline(deadline)
        except ValueError:
            await interaction.response.send_message(
                "❌ Deadline-Format: `TT.MM.JJJJ HH:MM`, z. B. `06.09.2026 14:55`.",
                ephemeral=True,
            )
            return

        if local_deadline <= datetime.now(VIENNA):
            await interaction.response.send_message(
                "❌ Die Deadline muss in der Zukunft liegen.",
                ephemeral=True,
            )
            return

        deadline_utc = local_deadline.astimezone(timezone.utc).isoformat()

    channel_id = (
        erinnerungs_channel.id
        if erinnerungs_channel
        else interaction.channel_id
    )

    async with db_lock:
        with get_db() as con:
            con.execute(
                """
                INSERT INTO rounds (
                    grand_prix, deadline_utc, status, has_sprint,
                    channel_id, created_by, created_at_utc
                )
                VALUES (?, ?, 'OPEN', ?, ?, ?, ?)
                """,
                (
                    clean(grand_prix),
                    deadline_utc,
                    sprint.value,
                    channel_id,
                    interaction.user.id,
                    now_iso(),
                ),
            )
            con.commit()

    e = make_embed(f"🏁 Neue Prediction — {clean(grand_prix)}")
    e.add_field(
        name="Sprint",
        value="✅ Ja" if sprint.value else "❌ Nein",
        inline=True,
    )

    if deadline_utc:
        e.add_field(
            name="Deadline",
            value=discord_time(deadline_utc),
            inline=False,
        )
        e.add_field(
            name="Automatische Erinnerungen",
            value=(
                f"<#{channel_id}>\n"
                f"• {REMINDER_1_MINUTES} Minuten vorher\n"
                f"• {REMINDER_2_MINUTES} Minuten vorher"
            ),
            inline=False,
        )
    else:
        e.add_field(
            name="Deadline",
            value=(
                "**Keine Deadline gesetzt.**\n"
                "Die Runde bleibt offen, bis die Predictionleitung "
                "`/closeprediction` oder `/setpredictionresult` verwendet."
            ),
            inline=False,
        )

    e.add_field(
        name="Fahrer-Auswahl",
        value="Die Fahrer werden direkt aus den Discord-Servermitgliedern ausgewählt.",
        inline=False,
    )
    e.set_footer(text="Tipp abgeben oder ändern: /predict")
    await interaction.response.send_message(embed=e)


# ============================================================
# Prediction abgeben
# ============================================================

@tree.command(name="predict", description="Gib deinen Tipp für die aktuelle Prediction ab.")
@app_commands.describe(
    pole="Discord-Mitglied für die Pole Position",
    p1="Rennsieger",
    p2="P2",
    p3="P3",
    fastest_lap="Fahrer mit der schnellsten Rennrunde",
    safety_car="Kommt mindestens ein Safety Car?",
    dnf="Optional: ein Fahrer, der DNF geht. Leer = kein DNF",
    sprint_p1="Nur bei Sprint-Wochenenden",
    sprint_p2="Nur bei Sprint-Wochenenden",
    sprint_p3="Nur bei Sprint-Wochenenden",
)
@app_commands.choices(
    safety_car=[
        app_commands.Choice(name="Ja", value="Ja"),
        app_commands.Choice(name="Nein", value="Nein"),
    ]
)
async def predict(
    interaction: discord.Interaction,
    pole: discord.Member,
    p1: discord.Member,
    p2: discord.Member,
    p3: discord.Member,
    fastest_lap: discord.Member,
    safety_car: app_commands.Choice[str],
    dnf: Optional[discord.Member] = None,
    sprint_p1: Optional[discord.Member] = None,
    sprint_p2: Optional[discord.Member] = None,
    sprint_p3: Optional[discord.Member] = None,
):
    row = await current_round()
    row = await maybe_auto_close(row)

    if not row or row["status"] != "OPEN":
        await interaction.response.send_message(
            "❌ Aktuell ist keine Prediction-Runde offen.",
            ephemeral=True,
        )
        return

    normal_members = [pole, p1, p2, p3, fastest_lap]
    if any(not valid_human_member(x) for x in normal_members):
        await interaction.response.send_message(
            "❌ Bots können nicht als Fahrer ausgewählt werden.",
            ephemeral=True,
        )
        return

    if dnf is not None and dnf.bot:
        await interaction.response.send_message(
            "❌ Ein Bot kann kein DNF-Tipp sein.",
            ephemeral=True,
        )
        return

    if len({p1.id, p2.id, p3.id}) != 3:
        await interaction.response.send_message(
            "❌ P1, P2 und P3 müssen drei unterschiedliche Fahrer sein.",
            ephemeral=True,
        )
        return

    sprint_members = [sprint_p1, sprint_p2, sprint_p3]

    if row["has_sprint"]:
        if any(x is None for x in sprint_members):
            await interaction.response.send_message(
                "❌ Dieses Wochenende hat einen Sprint. "
                "Bitte Sprint P1, P2 und P3 ausfüllen.",
                ephemeral=True,
            )
            return

        if any(x.bot for x in sprint_members):
            await interaction.response.send_message(
                "❌ Bots können nicht als Sprint-Fahrer ausgewählt werden.",
                ephemeral=True,
            )
            return

        if len({x.id for x in sprint_members}) != 3:
            await interaction.response.send_message(
                "❌ Sprint P1, P2 und P3 müssen unterschiedlich sein.",
                ephemeral=True,
            )
            return
    else:
        sprint_members = [None, None, None]

    packed = {
        "pole": pack_member(pole),
        "p1": pack_member(p1),
        "p2": pack_member(p2),
        "p3": pack_member(p3),
        "fastest_lap": pack_member(fastest_lap),
        "dnf": pack_member(dnf) if dnf else None,
        "sprint_p1": pack_member(sprint_members[0]) if sprint_members[0] else None,
        "sprint_p2": pack_member(sprint_members[1]) if sprint_members[1] else None,
        "sprint_p3": pack_member(sprint_members[2]) if sprint_members[2] else None,
    }

    async with db_lock:
        with get_db() as con:
            con.execute(
                """
                INSERT INTO predictions (
                    round_id, user_id, user_name,
                    pole, p1, p2, p3,
                    fastest_lap, dnf, safety_car,
                    sprint_p1, sprint_p2, sprint_p3,
                    submitted_at_utc, points
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL)
                ON CONFLICT(round_id, user_id) DO UPDATE SET
                    user_name=excluded.user_name,
                    pole=excluded.pole,
                    p1=excluded.p1,
                    p2=excluded.p2,
                    p3=excluded.p3,
                    fastest_lap=excluded.fastest_lap,
                    dnf=excluded.dnf,
                    safety_car=excluded.safety_car,
                    sprint_p1=excluded.sprint_p1,
                    sprint_p2=excluded.sprint_p2,
                    sprint_p3=excluded.sprint_p3,
                    submitted_at_utc=excluded.submitted_at_utc,
                    points=NULL
                """,
                (
                    row["id"],
                    interaction.user.id,
                    interaction.user.display_name,
                    packed["pole"],
                    packed["p1"],
                    packed["p2"],
                    packed["p3"],
                    packed["fastest_lap"],
                    packed["dnf"],
                    safety_car.value,
                    packed["sprint_p1"],
                    packed["sprint_p2"],
                    packed["sprint_p3"],
                    now_iso(),
                ),
            )
            con.commit()

    e = make_embed("✅ Prediction gespeichert")
    e.add_field(
        name="Hauptrennen",
        value=(
            f"🎯 Pole: **{pole.display_name}**\n"
            f"🥇 P1: **{p1.display_name}**\n"
            f"🥈 P2: **{p2.display_name}**\n"
            f"🥉 P3: **{p3.display_name}**\n"
            f"⚡ Fastest Lap: **{fastest_lap.display_name}**\n"
            f"💥 DNF: **{dnf.display_name if dnf else 'Kein DNF'}**\n"
            f"🚨 Safety Car: **{safety_car.value}**"
        ),
        inline=False,
    )

    if row["has_sprint"]:
        e.add_field(
            name="Sprint",
            value=(
                f"🥇 **{sprint_members[0].display_name}**\n"
                f"🥈 **{sprint_members[1].display_name}**\n"
                f"🥉 **{sprint_members[2].display_name}**"
            ),
            inline=False,
        )

    if has_deadline(row):
        e.add_field(name="Deadline", value=discord_time(row["deadline_utc"]), inline=False)
    else:
        e.add_field(name="Deadline", value="Keine feste Deadline", inline=False)

    e.set_footer(text="Solange die Runde offen ist, kannst du /predict erneut verwenden.")
    await interaction.response.send_message(embed=e, ephemeral=True)


# ============================================================
# Bonusfragen
# ============================================================

@tree.command(name="addbonusquestion", description="Fügt der aktuellen Runde eine Bonusfrage hinzu.")
@app_commands.describe(
    frage="z. B. Gibt es eine rote Flagge?",
    option_a="z. B. Ja",
    option_b="z. B. Nein",
    punkte="Punkte für die richtige Antwort",
)
async def addbonusquestion(
    interaction: discord.Interaction,
    frage: str,
    option_a: str,
    option_b: str,
    punkte: app_commands.Range[int, 1, 20] = 3,
):
    if not await require_manager(interaction):
        return

    row = await current_round()
    row = await maybe_auto_close(row)

    if not row or row["status"] != "OPEN":
        await interaction.response.send_message(
            "❌ Keine offene Prediction-Runde.",
            ephemeral=True,
        )
        return

    if norm(option_a) == norm(option_b):
        await interaction.response.send_message(
            "❌ Die beiden Antwortmöglichkeiten müssen unterschiedlich sein.",
            ephemeral=True,
        )
        return

    async with db_lock:
        with get_db() as con:
            cur = con.execute(
                """
                INSERT INTO bonus_questions (
                    round_id, question, option_a, option_b,
                    points, created_by, created_at_utc
                )
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    row["id"],
                    clean(frage),
                    clean(option_a),
                    clean(option_b),
                    int(punkte),
                    interaction.user.id,
                    now_iso(),
                ),
            )
            qid = cur.lastrowid
            con.commit()

    await interaction.response.send_message(
        f"🎁 Bonusfrage **#{qid}** hinzugefügt:\n"
        f"**{clean(frage)}**\n"
        f"`{clean(option_a)}` oder `{clean(option_b)}` · **{punkte} P**"
    )


@tree.command(name="bonusquestions", description="Zeigt die Bonusfragen der aktuellen Runde.")
async def bonusquestions(interaction: discord.Interaction):
    row = await current_round() or await current_round(include_scored=True)

    if not row:
        await interaction.response.send_message("ℹ️ Keine Prediction-Runde.", ephemeral=True)
        return

    async with db_lock:
        with get_db() as con:
            questions = con.execute(
                """
                SELECT * FROM bonus_questions
                WHERE round_id=?
                ORDER BY id
                """,
                (row["id"],),
            ).fetchall()

    if not questions:
        await interaction.response.send_message(
            "ℹ️ Für diese Runde gibt es keine Bonusfragen.",
            ephemeral=True,
        )
        return

    lines = []
    for q in questions:
        result = f" · ✅ **{q['correct_answer']}**" if q["correct_answer"] else ""
        lines.append(
            f"**#{q['id']} — {q['question']}**\n"
            f"`{q['option_a']}` oder `{q['option_b']}` · **{q['points']} P**{result}"
        )

    e = make_embed(f"🎁 Bonusfragen — {row['grand_prix']}", "\n\n".join(lines))
    e.set_footer(text="Antworten mit /bonuspredict")
    await interaction.response.send_message(embed=e)


@tree.command(name="bonuspredict", description="Beantworte eine Bonusfrage.")
@app_commands.describe(frage="Bonusfrage auswählen", antwort="Antwort auswählen")
@app_commands.autocomplete(
    frage=bonus_question_autocomplete,
    antwort=bonus_answer_autocomplete,
)
async def bonuspredict(
    interaction: discord.Interaction,
    frage: str,
    antwort: str,
):
    row = await current_round()
    row = await maybe_auto_close(row)

    if not row or row["status"] != "OPEN":
        await interaction.response.send_message(
            "❌ Aktuell sind keine Bonus-Predictions offen.",
            ephemeral=True,
        )
        return

    try:
        qid = int(frage)
    except ValueError:
        await interaction.response.send_message("❌ Ungültige Bonusfrage.", ephemeral=True)
        return

    async with db_lock:
        with get_db() as con:
            q = con.execute(
                """
                SELECT * FROM bonus_questions
                WHERE id=? AND round_id=?
                """,
                (qid, row["id"]),
            ).fetchone()

    if not q:
        await interaction.response.send_message("❌ Bonusfrage nicht gefunden.", ephemeral=True)
        return

    if norm(antwort) not in {norm(q["option_a"]), norm(q["option_b"])}:
        await interaction.response.send_message(
            "❌ Bitte eine der beiden Antwortmöglichkeiten auswählen.",
            ephemeral=True,
        )
        return

    answer = q["option_a"] if norm(antwort) == norm(q["option_a"]) else q["option_b"]

    async with db_lock:
        with get_db() as con:
            con.execute(
                """
                INSERT INTO bonus_answers (
                    question_id, round_id, user_id, user_name,
                    answer, points_earned, submitted_at_utc
                )
                VALUES (?, ?, ?, ?, ?, NULL, ?)
                ON CONFLICT(question_id, user_id) DO UPDATE SET
                    user_name=excluded.user_name,
                    answer=excluded.answer,
                    points_earned=NULL,
                    submitted_at_utc=excluded.submitted_at_utc
                """,
                (
                    qid,
                    row["id"],
                    interaction.user.id,
                    interaction.user.display_name,
                    answer,
                    now_iso(),
                ),
            )
            con.commit()

    await interaction.response.send_message(
        f"✅ Bonusfrage **#{qid}** gespeichert: **{answer}**",
        ephemeral=True,
    )


@tree.command(name="setbonusanswer", description="Wertet eine Bonusfrage aus.")
@app_commands.describe(frage="Bonusfrage auswählen", antwort="Richtige Antwort")
@app_commands.autocomplete(
    frage=bonus_question_autocomplete,
    antwort=bonus_answer_autocomplete,
)
async def setbonusanswer(
    interaction: discord.Interaction,
    frage: str,
    antwort: str,
):
    if not await require_manager(interaction):
        return

    try:
        qid = int(frage)
    except ValueError:
        await interaction.response.send_message("❌ Ungültige Bonusfrage.", ephemeral=True)
        return

    async with db_lock:
        with get_db() as con:
            q = con.execute(
                "SELECT * FROM bonus_questions WHERE id=?",
                (qid,),
            ).fetchone()

            if not q:
                await interaction.response.send_message(
                    "❌ Bonusfrage nicht gefunden.",
                    ephemeral=True,
                )
                return

            if norm(antwort) not in {norm(q["option_a"]), norm(q["option_b"])}:
                await interaction.response.send_message(
                    "❌ Ungültige Antwort.",
                    ephemeral=True,
                )
                return

            correct = q["option_a"] if norm(antwort) == norm(q["option_a"]) else q["option_b"]

            con.execute(
                "UPDATE bonus_questions SET correct_answer=? WHERE id=?",
                (correct, qid),
            )
            con.execute(
                """
                UPDATE bonus_answers
                SET points_earned =
                    CASE
                        WHEN LOWER(TRIM(answer)) = LOWER(TRIM(?)) THEN ?
                        ELSE 0
                    END
                WHERE question_id=?
                """,
                (correct, q["points"], qid),
            )
            con.commit()

    await interaction.response.send_message(
        f"✅ Bonusfrage **#{qid}** ausgewertet. Richtige Antwort: **{correct}**"
    )


# ============================================================
# Ergebnis / Auswertung
# ============================================================

@tree.command(name="setpredictionresult", description="Trägt das Ergebnis ein und wertet die Runde aus.")
@app_commands.describe(
    pole="Pole-Sitter",
    p1="Rennsieger",
    p2="P2",
    p3="P3",
    fastest_lap="Schnellste Rennrunde",
    safety_car="Gab es mindestens ein Safety Car?",
    dnf="Optional: ein DNF-Fahrer. Leer = kein DNF",
    sprint_p1="Nur beim Sprint",
    sprint_p2="Nur beim Sprint",
    sprint_p3="Nur beim Sprint",
)
@app_commands.choices(
    safety_car=[
        app_commands.Choice(name="Ja", value="Ja"),
        app_commands.Choice(name="Nein", value="Nein"),
    ]
)
async def setpredictionresult(
    interaction: discord.Interaction,
    pole: discord.Member,
    p1: discord.Member,
    p2: discord.Member,
    p3: discord.Member,
    fastest_lap: discord.Member,
    safety_car: app_commands.Choice[str],
    dnf: Optional[discord.Member] = None,
    sprint_p1: Optional[discord.Member] = None,
    sprint_p2: Optional[discord.Member] = None,
    sprint_p3: Optional[discord.Member] = None,
):
    if not await require_manager(interaction):
        return

    row = await current_round()

    if not row:
        await interaction.response.send_message(
            "❌ Keine Runde zum Auswerten.",
            ephemeral=True,
        )
        return

    normal_members = [pole, p1, p2, p3, fastest_lap]
    if any(not valid_human_member(x) for x in normal_members):
        await interaction.response.send_message(
            "❌ Bots können nicht als Fahrer ausgewählt werden.",
            ephemeral=True,
        )
        return

    if dnf is not None and dnf.bot:
        await interaction.response.send_message(
            "❌ Ein Bot kann kein DNF-Fahrer sein.",
            ephemeral=True,
        )
        return

    if len({p1.id, p2.id, p3.id}) != 3:
        await interaction.response.send_message(
            "❌ P1, P2 und P3 müssen unterschiedlich sein.",
            ephemeral=True,
        )
        return

    sprint_members = [sprint_p1, sprint_p2, sprint_p3]

    if row["has_sprint"]:
        if any(x is None for x in sprint_members):
            await interaction.response.send_message(
                "❌ Sprint P1, P2 und P3 fehlen.",
                ephemeral=True,
            )
            return

        if any(x.bot for x in sprint_members):
            await interaction.response.send_message(
                "❌ Bots können nicht als Sprint-Fahrer ausgewählt werden.",
                ephemeral=True,
            )
            return

        if len({x.id for x in sprint_members}) != 3:
            await interaction.response.send_message(
                "❌ Sprint P1/P2/P3 müssen unterschiedlich sein.",
                ephemeral=True,
            )
            return
    else:
        sprint_members = [None, None, None]

    await interaction.response.defer()

    async with db_lock:
        with get_db() as con:
            con.execute(
                """
                UPDATE rounds SET
                    status='CLOSED',
                    pole_result=?,
                    p1_result=?,
                    p2_result=?,
                    p3_result=?,
                    fastest_lap_result=?,
                    dnf_result=?,
                    safety_car_result=?,
                    sprint_p1_result=?,
                    sprint_p2_result=?,
                    sprint_p3_result=?
                WHERE id=?
                """,
                (
                    pack_member(pole),
                    pack_member(p1),
                    pack_member(p2),
                    pack_member(p3),
                    pack_member(fastest_lap),
                    pack_member(dnf) if dnf else None,
                    safety_car.value,
                    pack_member(sprint_members[0]) if sprint_members[0] else None,
                    pack_member(sprint_members[1]) if sprint_members[1] else None,
                    pack_member(sprint_members[2]) if sprint_members[2] else None,
                    row["id"],
                ),
            )

            result = con.execute(
                "SELECT * FROM rounds WHERE id=?",
                (row["id"],),
            ).fetchone()

            predictions = con.execute(
                "SELECT * FROM predictions WHERE round_id=?",
                (row["id"],),
            ).fetchall()

            ranking = []

            for pred in predictions:
                pts = score_prediction(pred, result)
                con.execute(
                    """
                    UPDATE predictions
                    SET points=?
                    WHERE round_id=? AND user_id=?
                    """,
                    (pts, row["id"], pred["user_id"]),
                )
                ranking.append((pred["user_name"], pts))

            con.execute(
                """
                UPDATE rounds
                SET status='SCORED', scored_at_utc=?
                WHERE id=?
                """,
                (now_iso(), row["id"]),
            )
            con.commit()

    ranking.sort(key=lambda x: (-x[1], x[0].casefold()))

    e = make_embed(f"🏆 Prediction ausgewertet — {row['grand_prix']}")
    e.add_field(
        name="Hauptrennen",
        value=(
            f"🎯 Pole: **{pole.display_name}**\n"
            f"🥇 **{p1.display_name}**\n"
            f"🥈 **{p2.display_name}**\n"
            f"🥉 **{p3.display_name}**\n"
            f"⚡ Fastest Lap: **{fastest_lap.display_name}**\n"
            f"💥 DNF: **{dnf.display_name if dnf else 'Kein DNF'}**\n"
            f"🚨 Safety Car: **{safety_car.value}**"
        ),
        inline=False,
    )

    if row["has_sprint"]:
        e.add_field(
            name="Sprint",
            value=(
                f"🥇 **{sprint_members[0].display_name}**\n"
                f"🥈 **{sprint_members[1].display_name}**\n"
                f"🥉 **{sprint_members[2].display_name}**"
            ),
            inline=False,
        )

    if ranking:
        medals = ["🥇", "🥈", "🥉"]
        lines = []
        for i, (name, pts) in enumerate(ranking[:10], 1):
            prefix = medals[i - 1] if i <= 3 else f"`{i}.`"
            lines.append(f"{prefix} **{name}** — **{pts} P**")
        e.add_field(
            name="Rundenwertung (ohne ggf. offene Bonusfragen)",
            value="\n".join(lines),
            inline=False,
        )

    e.set_footer(text="Offene Bonusfragen ggf. noch mit /setbonusanswer auswerten.")
    await interaction.followup.send(embed=e)


# ============================================================
# Anzeigen / Verwaltung
# ============================================================

@tree.command(name="myprediction", description="Zeigt deinen Tipp für die aktuelle oder letzte Runde.")
async def myprediction(interaction: discord.Interaction):
    row = await current_round() or await current_round(include_scored=True)

    if not row:
        await interaction.response.send_message("ℹ️ Keine Prediction-Runde.", ephemeral=True)
        return

    async with db_lock:
        with get_db() as con:
            pred = con.execute(
                """
                SELECT * FROM predictions
                WHERE round_id=? AND user_id=?
                """,
                (row["id"], interaction.user.id),
            ).fetchone()

            bonuses = con.execute(
                """
                SELECT q.id, q.question, a.answer, a.points_earned
                FROM bonus_answers a
                JOIN bonus_questions q ON q.id=a.question_id
                WHERE a.round_id=? AND a.user_id=?
                ORDER BY q.id
                """,
                (row["id"], interaction.user.id),
            ).fetchall()

    if not pred:
        await interaction.response.send_message(
            f"ℹ️ Du hast für **{row['grand_prix']}** noch keinen Tipp abgegeben.",
            ephemeral=True,
        )
        return

    e = make_embed(f"🔮 Dein Tipp — {row['grand_prix']}")
    e.add_field(
        name="Hauptrennen",
        value=(
            f"🎯 Pole: **{driver_name(pred['pole'])}**\n"
            f"🥇 P1: **{driver_name(pred['p1'])}**\n"
            f"🥈 P2: **{driver_name(pred['p2'])}**\n"
            f"🥉 P3: **{driver_name(pred['p3'])}**\n"
            f"⚡ Fastest Lap: **{driver_name(pred['fastest_lap'])}**\n"
            f"💥 DNF: **{driver_name(pred['dnf']) if pred['dnf'] else 'Kein DNF'}**\n"
            f"🚨 Safety Car: **{pred['safety_car']}**"
        ),
        inline=False,
    )

    if row["has_sprint"]:
        e.add_field(
            name="Sprint",
            value=(
                f"🥇 **{driver_name(pred['sprint_p1'])}**\n"
                f"🥈 **{driver_name(pred['sprint_p2'])}**\n"
                f"🥉 **{driver_name(pred['sprint_p3'])}**"
            ),
            inline=False,
        )

    if bonuses:
        bonus_lines = []
        for b in bonuses:
            pts = f" · **{b['points_earned']} P**" if b["points_earned"] is not None else ""
            bonus_lines.append(f"#{b['id']} **{b['answer']}**{pts}")
        e.add_field(name="Bonusfragen", value="\n".join(bonus_lines), inline=False)

    if pred["points"] is not None:
        bonus_total = sum((b["points_earned"] or 0) for b in bonuses)
        e.add_field(
            name="Gesamtpunkte dieser Runde",
            value=f"**{pred['points'] + bonus_total} P**",
            inline=False,
        )

    await interaction.response.send_message(embed=e, ephemeral=True)


@tree.command(name="predictionstandings", description="Zeigt die Gesamtwertung.")
async def predictionstandings(interaction: discord.Interaction):
    async with db_lock:
        with get_db() as con:
            rows = con.execute(
                """
                WITH p AS (
                    SELECT
                        user_id,
                        MAX(user_name) AS user_name,
                        COALESCE(SUM(points),0) AS pts,
                        COUNT(CASE WHEN points IS NOT NULL THEN 1 END) AS races
                    FROM predictions
                    GROUP BY user_id
                ),
                b AS (
                    SELECT
                        user_id,
                        MAX(user_name) AS user_name,
                        COALESCE(SUM(points_earned),0) AS pts
                    FROM bonus_answers
                    GROUP BY user_id
                ),
                u AS (
                    SELECT user_id FROM p
                    UNION
                    SELECT user_id FROM b
                )
                SELECT
                    u.user_id,
                    COALESCE(p.user_name,b.user_name) AS user_name,
                    COALESCE(p.pts,0)+COALESCE(b.pts,0) AS total,
                    COALESCE(p.races,0) AS races
                FROM u
                LEFT JOIN p ON p.user_id=u.user_id
                LEFT JOIN b ON b.user_id=u.user_id
                ORDER BY total DESC, user_name COLLATE NOCASE
                """
            ).fetchall()

    if not rows:
        await interaction.response.send_message("ℹ️ Noch keine Wertung.", ephemeral=True)
        return

    medals = ["🥇", "🥈", "🥉"]
    lines = []
    for i, r in enumerate(rows[:25], 1):
        prefix = medals[i - 1] if i <= 3 else f"`{i}.`"
        lines.append(
            f"{prefix} **{r['user_name']}** — **{r['total']} P** · {r['races']} Rennen"
        )

    await interaction.response.send_message(
        embed=make_embed("🏆 WTV Prediction Championship", "\n".join(lines))
    )


@tree.command(name="predictionhistory", description="Zeigt die letzten ausgewerteten Runden.")
async def predictionhistory(interaction: discord.Interaction):
    async with db_lock:
        with get_db() as con:
            rows = con.execute(
                """
                SELECT grand_prix, p1_result, has_sprint
                FROM rounds
                WHERE status='SCORED'
                ORDER BY id DESC
                LIMIT 10
                """
            ).fetchall()

    if not rows:
        await interaction.response.send_message(
            "ℹ️ Noch keine ausgewerteten Runden.",
            ephemeral=True,
        )
        return

    lines = []
    for r in rows:
        lines.append(
            f"**{r['grand_prix']}** — Sieger: **{driver_name(r['p1_result'])}**"
            + (" · Sprint" if r["has_sprint"] else "")
        )

    await interaction.response.send_message(
        embed=make_embed("📚 Prediction-Historie", "\n".join(lines))
    )


@tree.command(name="predictioninfo", description="Zeigt die aktuelle Prediction-Runde.")
async def predictioninfo(interaction: discord.Interaction):
    row = await current_round() or await current_round(include_scored=True)
    row = await maybe_auto_close(row)

    if not row:
        await interaction.response.send_message("ℹ️ Keine Prediction-Runde.", ephemeral=True)
        return

    e = make_embed(f"🏎️ {row['grand_prix']}")
    e.add_field(name="Status", value=status_text(row["status"]), inline=True)
    e.add_field(name="Sprint", value="✅ Ja" if row["has_sprint"] else "❌ Nein", inline=True)

    if has_deadline(row):
        e.add_field(name="Deadline", value=discord_time(row["deadline_utc"]), inline=False)
    else:
        e.add_field(
            name="Deadline",
            value="Keine feste Deadline – manuelle Schließung durch die Predictionleitung.",
            inline=False,
        )

    e.add_field(name="Punktesystem", value=scoring_text(bool(row["has_sprint"])), inline=False)
    await interaction.response.send_message(embed=e)


@tree.command(name="allpredictions", description="Zeigt der Predictionleitung alle Tipps.")
async def allpredictions(interaction: discord.Interaction):
    if not await require_manager(interaction):
        return

    row = await current_round() or await current_round(include_scored=True)
    if not row:
        await interaction.response.send_message("❌ Keine Runde vorhanden.", ephemeral=True)
        return

    async with db_lock:
        with get_db() as con:
            preds = con.execute(
                """
                SELECT * FROM predictions
                WHERE round_id=?
                ORDER BY user_name COLLATE NOCASE
                """,
                (row["id"],),
            ).fetchall()

    if not preds:
        await interaction.response.send_message("ℹ️ Noch keine Tipps.", ephemeral=True)
        return

    lines = []
    for p in preds:
        line = (
            f"**{p['user_name']}**\n"
            f"Pole `{driver_name(p['pole'])}` · "
            f"P1 `{driver_name(p['p1'])}` · "
            f"P2 `{driver_name(p['p2'])}` · "
            f"P3 `{driver_name(p['p3'])}`\n"
            f"FL `{driver_name(p['fastest_lap'])}` · "
            f"DNF `{driver_name(p['dnf']) if p['dnf'] else 'Kein DNF'}` · "
            f"SC `{p['safety_car']}`"
        )

        if row["has_sprint"]:
            line += (
                f"\nSprint `{driver_name(p['sprint_p1'])}` / "
                f"`{driver_name(p['sprint_p2'])}` / "
                f"`{driver_name(p['sprint_p3'])}`"
            )

        if p["points"] is not None:
            line += f"\n**{p['points']} P**"

        lines.append(line)

    text = "\n\n".join(lines)
    if len(text) > 3900:
        text = text[:3850] + "\n\n… Anzeige gekürzt."

    await interaction.response.send_message(
        embed=make_embed(f"📋 Predictions — {row['grand_prix']}", text),
        ephemeral=True,
    )


@tree.command(name="closeprediction", description="Schließt die offene Prediction manuell.")
async def closeprediction(interaction: discord.Interaction):
    if not await require_manager(interaction):
        return

    row = await current_round()
    if not row or row["status"] != "OPEN":
        await interaction.response.send_message(
            "❌ Keine offene Runde.",
            ephemeral=True,
        )
        return

    async with db_lock:
        with get_db() as con:
            con.execute(
                "UPDATE rounds SET status='CLOSED' WHERE id=?",
                (row["id"],),
            )
            con.commit()

    await interaction.response.send_message(
        f"🔒 **{row['grand_prix']}** wurde geschlossen."
    )


@tree.command(name="deletepredictionround", description="Löscht die aktuelle offene/geschlossene Runde.")
async def deletepredictionround(interaction: discord.Interaction):
    if not await require_manager(interaction):
        return

    row = await current_round()
    if not row:
        await interaction.response.send_message(
            "❌ Keine löschbare Runde.",
            ephemeral=True,
        )
        return

    async with db_lock:
        with get_db() as con:
            qids = [
                r["id"]
                for r in con.execute(
                    "SELECT id FROM bonus_questions WHERE round_id=?",
                    (row["id"],),
                ).fetchall()
            ]

            if qids:
                placeholders = ",".join("?" for _ in qids)
                con.execute(
                    f"DELETE FROM bonus_answers WHERE question_id IN ({placeholders})",
                    qids,
                )

            con.execute("DELETE FROM bonus_questions WHERE round_id=?", (row["id"],))
            con.execute("DELETE FROM predictions WHERE round_id=?", (row["id"],))
            con.execute("DELETE FROM rounds WHERE id=?", (row["id"],))
            con.commit()

    await interaction.response.send_message(
        f"🗑️ **{row['grand_prix']}** samt Tipps und Bonusfragen wurde gelöscht.",
        ephemeral=True,
    )


@tree.command(name="predictionhelp", description="Zeigt die Commands des Bots.")
async def predictionhelp(interaction: discord.Interaction):
    e = make_embed("❓ WTV Prediction Bot V4")
    e.add_field(
        name="👥 Für alle",
        value=(
            "`/predict` — Prediction abgeben/ändern\n"
            "`/bonuspredict` — Bonusfrage beantworten\n"
            "`/myprediction` — eigenen Tipp ansehen\n"
            "`/predictioninfo` — aktuelle Runde\n"
            "`/predictionstandings` — Gesamtwertung\n"
            "`/predictionhistory` — Historie\n"
            "`/bonusquestions` — Bonusfragen"
        ),
        inline=False,
    )
    e.add_field(
        name=f"🛠️ {MANAGER_ROLE_NAME} / Admin",
        value=(
            "`/newprediction` — neue Runde\n"
            "`/addbonusquestion` — Bonusfrage\n"
            "`/setbonusanswer` — Bonusfrage auswerten\n"
            "`/closeprediction` — manuell schließen\n"
            "`/setpredictionresult` — Ergebnis + Auswertung\n"
            "`/allpredictions` — alle Tipps\n"
            "`/deletepredictionround` — Test-/Fehlerrunde löschen"
        ),
        inline=False,
    )
    e.add_field(
        name="ℹ️ Fahrer",
        value=(
            "Es gibt keine manuelle Fahrerliste mehr. "
            "Bei `/predict` und `/setpredictionresult` werden "
            "Discord-Servermitglieder direkt ausgewählt."
        ),
        inline=False,
    )
    await interaction.response.send_message(embed=e, ephemeral=True)


# ============================================================
# Errors / Start
# ============================================================

@tree.error
async def on_app_command_error(
    interaction: discord.Interaction,
    error: app_commands.AppCommandError,
):
    print(f"AppCommandError: {error!r}")
    msg = "❌ Beim Ausführen des Commands ist ein Fehler aufgetreten."

    if interaction.response.is_done():
        await interaction.followup.send(msg, ephemeral=True)
    else:
        await interaction.response.send_message(msg, ephemeral=True)


if __name__ == "__main__":
    if not TOKEN:
        raise RuntimeError("DISCORD_TOKEN fehlt.")
    bot.run(TOKEN)
