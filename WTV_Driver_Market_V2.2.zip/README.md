# WTV Driver Market V2.2

Die Aktuelle stabile Hauptversion: **V2.2**.

## Neu ergänzt
- `/help`
- `/saison`

### `/help`
Öffentliche Übersicht über alle Commands der V2.2 und deren Berechtigungen.

### `/saison`
Nur für Discord-Administratoren.

Beispiel:
```text
/saison nummer:6
```

Setzt die aktuelle Saison direkt auf Saison 6. Dabei werden **keine**
Fahrer-, Vertrags-, Marktwert- oder Transferdaten verändert.

Die aktuelle Saison wird außerdem bei `/drivermarket`, `/alldrivers`,
`/driverinfo` und `/help` angezeigt.

## Commands

### Öffentlich
- `/drivermarket`
- `/alldrivers`
- `/driverinfo`
- `/help`

### Nur Administrator
- `/adddriver`
- `/editdriver`
- `/transferdriver`
- `/removedriver`
- `/saison`
