# WTV Driver Market V2.1

V2.1 basiert auf V2.

## Änderung gegenüber V2
Die Änderungs-Commands sind jetzt nur noch für Nutzer mit der Discord-Berechtigung **Administrator** verfügbar.

### Öffentlich
- /drivermarket
- /alldrivers
- /driverinfo

### Nur Administrator
- /adddriver
- /editdriver
- /transferdriver
- /removedriver

## Weiterhin enthalten
- automatische Team-Erkennung über Discord-Teamrollen
- Fahrer ohne bekannte Teamrolle werden als Frei eingetragen
- /transferdriver kann Teamrollen automatisch wechseln
- Red Bull Racing und Ferrari sind als Test-Teamrollen hinterlegt

## Wichtig für /transferdriver
Der Bot selbst braucht weiterhin die Berechtigung **Rollen verwalten** und seine Bot-Rolle muss über den Teamrollen stehen.
